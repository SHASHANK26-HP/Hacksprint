import React, { useState, useMemo } from 'react';
import { Header, NavTab } from './components/Header';
import { WorkbenchQueue } from './components/WorkbenchQueue';
import { EvidenceDossier } from './components/EvidenceDossier';
import { BatchSandbox } from './components/BatchSandbox';
import { ModelAnalytics } from './components/ModelAnalytics';
import { PolicyRules } from './components/PolicyRules';
import { DuplicateDiffModal } from './components/DuplicateDiffModal';
import { LoginPage } from './components/LoginPage';
import { ProviderPortal } from './components/ProviderPortal';
import { INITIAL_CLAIMS } from './data/mockClaims';
import { DEFAULT_POLICY_RULES, runDetectionEngine } from './engine/detectionEngine';
import { Claim, ClaimStatus, PolicyRule, UserProfile } from './types';

const DEFAULT_COMPANY_USER: UserProfile = {
  id: 'USR-COMPANY-01',
  name: 'Vikram Sethi',
  email: 'investigator.sethi@claimguard-insurance.com',
  role: 'insurer_auditor',
  portalType: 'company',
  organization: 'ClaimGuard General Health Insurance',
  department: 'Special Investigation Unit (SIU)',
};

const DEFAULT_PROVIDER_USER: UserProfile = {
  id: 'USR-PROV-101',
  name: 'Dr. Anita Deshpande',
  email: 'billing.desk@apexhospital.org',
  role: 'healthcare_provider',
  portalType: 'provider',
  organization: 'Apex Multispecialty Hospital',
  facilityId: 'HSP-101',
  department: 'Revenue Cycle & Claims Compliance',
};

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(DEFAULT_COMPANY_USER);
  const [activeTab, setActiveTab] = useState<NavTab>('queue');
  const [claims, setClaims] = useState<Claim[]>(INITIAL_CLAIMS);
  const [rules, setRules] = useState<PolicyRule[]>(DEFAULT_POLICY_RULES);
  const [selectedClaimId, setSelectedClaimId] = useState<string>('CLM-45321');
  const [currency, setCurrency] = useState<'INR' | 'USD'>('INR');
  const [showDuplicateModal, setShowDuplicateModal] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Exchange rate for INR to USD display conversion
  const exchangeRate = 84.0;

  // Compute detection results dynamically for all claims based on active rules
  const detectionResults = useMemo(() => {
    const resultsMap = new Map();
    claims.forEach((claim) => {
      const result = runDetectionEngine(claim, claims, rules);
      resultsMap.set(claim.id, result);
    });
    return resultsMap;
  }, [claims, rules]);

  const selectedClaim = useMemo(() => {
    return claims.find((c) => c.id === selectedClaimId) || claims[0];
  }, [claims, selectedClaimId]);

  const selectedResult = useMemo(() => {
    if (!selectedClaim) return null;
    return detectionResults.get(selectedClaim.id) || null;
  }, [selectedClaim, detectionResults]);

  // Show toast notification helper
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Investigator Adjudication handler
  const handleAdjudicate = (
    claimId: string,
    newStatus: ClaimStatus,
    actionName: string,
    note: string
  ) => {
    setClaims((prev) =>
      prev.map((c) => {
        if (c.id !== claimId) return c;
        const newLog = {
          id: `LOG-${Date.now()}`,
          action: actionName,
          timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
          note,
          actor: 'Lead Investigator (Active Session)',
        };
        return {
          ...c,
          status: newStatus,
          historyLog: [newLog, ...c.historyLog],
        };
      })
    );
    showToast(`Adjudication saved for Claim #${claimId}: ${actionName}`);
  };

  // Quick approve clean claim
  const handleQuickApprove = (claimId: string) => {
    handleAdjudicate(
      claimId,
      'dismissed_clean',
      'Straight-Through Automated Approval',
      'Claim passed all actuarial and clinical compatibility guidelines without flags.'
    );
  };

  // Add newly simulated claim
  const handleIngestClaim = (newClaim: Claim) => {
    setClaims((prev) => [newClaim, ...prev]);
    setSelectedClaimId(newClaim.id);
    setActiveTab('dossier');
    showToast(`Claim #${newClaim.id} successfully audited and ingested!`);
  };

  // Toggle active policy rules
  const handleToggleRule = (ruleId: string) => {
    setRules((prev) =>
      prev.map((r) => (r.id === ruleId ? { ...r, enabled: !r.enabled } : r))
    );
    showToast(`Policy rule ${ruleId} updated.`);
  };

  // Respond to RFI from hospital
  const handleRespondRfi = (claimId: string, responseNote: string) => {
    setClaims((prev) =>
      prev.map((c) => {
        if (c.id !== claimId) return c;
        const newLog = {
          id: `LOG-${Date.now()}`,
          action: 'Hospital RFI Medical Documentation Submitted',
          timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
          note: responseNote,
          actor: currentUser ? currentUser.name : 'Hospital Billing Department',
        };
        return {
          ...c,
          status: 'investigating',
          historyLog: [newLog, ...c.historyLog],
        };
      })
    );
    showToast(`Documentation transmitted for Claim #${claimId}. Status updated to Investigating.`);
  };

  // Switch portal between Insurer and Hospital
  const handleSwitchPortal = () => {
    if (currentUser?.portalType === 'company') {
      setCurrentUser(DEFAULT_PROVIDER_USER);
      setActiveTab('provider_portal');
      showToast('Switched to Healthcare Provider Portal (Apex Multispecialty Hospital)');
    } else {
      setCurrentUser(DEFAULT_COMPANY_USER);
      setActiveTab('queue');
      showToast('Switched to Company Insurer Portal (ClaimGuard SIU)');
    }
  };

  const handleLogin = (user: UserProfile) => {
    setCurrentUser(user);
    if (user.portalType === 'provider') {
      setActiveTab('provider_portal');
    } else {
      setActiveTab('queue');
    }
    showToast(`Welcome, ${user.name}! Signed into ${user.portalType === 'company' ? 'Insurer' : 'Provider'} Portal.`);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    showToast('Signed out successfully.');
  };

  // If user is logged out, render the Login Page
  if (!currentUser) {
    return <LoginPage onLogin={handleLogin} />;
  }

  // Count claims pending review
  const pendingCount = useMemo(() => {
    return claims.filter((c) => c.status === 'pending_review' || c.status === 'investigating').length;
  }, [claims]);

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col font-sans selection:bg-indigo-500/30 selection:text-white">
      {/* Header matching 3-zone Top Bar Contract */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currency={currency}
        setCurrency={setCurrency}
        onOpenNewClaimModal={() => setActiveTab('sandbox')}
        pendingReviewCount={pendingCount}
        currentUser={currentUser}
        onLogout={handleLogout}
        onSwitchPortal={handleSwitchPortal}
      />

      {/* Main Workspace Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Toast Notification */}
        {toastMessage && (
          <div className="fixed bottom-6 right-6 z-50 bg-slate-900 border border-indigo-500/50 shadow-2xl rounded-xl px-4 py-3 text-xs text-indigo-200 flex items-center gap-2 animate-in fade-in slide-in-from-bottom-2 duration-200">
            <span className="w-2 h-2 rounded-full bg-indigo-400"></span>
            <span>{toastMessage}</span>
          </div>
        )}

        {/* View Routing */}
        {activeTab === 'provider_portal' && (
          <ProviderPortal
            currentUser={currentUser}
            claims={claims}
            detectionResults={detectionResults}
            onIngestClaim={handleIngestClaim}
            onRespondRfi={handleRespondRfi}
            currency={currency}
            exchangeRate={exchangeRate}
          />
        )}

        {activeTab === 'queue' && (
          <WorkbenchQueue
            claims={claims}
            detectionResults={detectionResults}
            selectedClaimId={selectedClaimId}
            onSelectClaim={(id) => {
              setSelectedClaimId(id);
              setActiveTab('dossier');
            }}
            currency={currency}
            exchangeRate={exchangeRate}
            onQuickApprove={handleQuickApprove}
            onViewDuplicateDiff={(id) => {
              setSelectedClaimId(id);
              setShowDuplicateModal(true);
            }}
          />
        )}

        {activeTab === 'dossier' && selectedClaim && selectedResult && (
          <EvidenceDossier
            claim={selectedClaim}
            result={selectedResult}
            currency={currency}
            exchangeRate={exchangeRate}
            onAdjudicate={handleAdjudicate}
            onOpenDuplicateDiff={() => setShowDuplicateModal(true)}
            allClaims={claims}
            onSelectClaim={(id) => setSelectedClaimId(id)}
          />
        )}

        {activeTab === 'sandbox' && (
          <BatchSandbox
            onIngestClaim={handleIngestClaim}
            currency={currency}
            exchangeRate={exchangeRate}
          />
        )}

        {activeTab === 'analytics' && (
          <ModelAnalytics
            claims={claims}
            detectionResults={detectionResults}
            currency={currency}
            exchangeRate={exchangeRate}
          />
        )}

        {activeTab === 'rules' && (
          <PolicyRules rules={rules} onToggleRule={handleToggleRule} />
        )}
      </main>

      {/* Side-by-Side Duplicate Diff Modal */}
      {showDuplicateModal && selectedClaim && selectedResult?.duplicateMatch && (
        <DuplicateDiffModal
          currentClaim={selectedClaim}
          match={selectedResult.duplicateMatch}
          currency={currency}
          exchangeRate={exchangeRate}
          onConfirmDuplicate={() => {
            handleAdjudicate(
              selectedClaim.id,
              'confirmed_fraud',
              'Confirmed Duplicate Billing Collision',
              `Claim matched 100% with prior record #${selectedResult.duplicateMatch?.matchedClaimId}. Rejected to prevent double reimbursement.`
            );
            setShowDuplicateModal(false);
          }}
          onDismissDuplicate={() => {
            handleAdjudicate(
              selectedClaim.id,
              'dismissed_clean',
              'Dismissed Duplicate Collision',
              'Confirmed valid separate clinical episode despite temporal proximity.'
            );
            setShowDuplicateModal(false);
          }}
          onClose={() => setShowDuplicateModal(false)}
        />
      )}

      {/* Subtle, Professional Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/40 py-6 mt-12 text-xs text-slate-500 text-center">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-400">ClaimGuard AI</span>
            <span>·</span>
            <span>Explainable Healthcare Claims Anomaly Detection & Fraud Review System</span>
          </div>
          <div className="flex items-center gap-4 text-slate-500 font-mono text-[11px]">
            <span>CMS / IRDAI Standard Crosswalk v2.4</span>
            <span>·</span>
            <span>SHAP / LIME Attribution Engine Active</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
