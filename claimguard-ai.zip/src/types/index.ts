export type RiskTier = 'auto_approve' | 'monitor' | 'investigate';

export type UserRole = 'insurer_auditor' | 'healthcare_provider';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  portalType: 'company' | 'provider';
  organization: string;
  facilityId?: string;
  avatar?: string;
  department?: string;
}

export type ClaimStatus =
  | 'pending_review'
  | 'investigating'
  | 'confirmed_fraud'
  | 'dismissed_clean'
  | 'rfi_requested'
  | 'siu_escalated';

export type AnomalyModule =
  | 'duplicate'
  | 'coding_error'
  | 'ml_anomaly'
  | 'provider_behavior'
  | 'utilization';

export interface AuditActionLog {
  id: string;
  action: string;
  timestamp: string;
  note: string;
  actor: string;
}

export interface Claim {
  id: string;
  patientId: string;
  patientName: string;
  patientAge: number;
  patientGender: 'M' | 'F' | 'Other';
  providerId: string;
  providerName: string;
  providerSpecialty: string;
  location: string;
  diagnosisCode: string; // ICD-10
  diagnosisDesc: string;
  procedureCode: string; // CPT / HCPCS
  procedureDesc: string;
  units: number;
  billedAmount: number; // in INR (currency toggle available in UI)
  serviceDate: string; // YYYY-MM-DD
  submissionDate: string; // YYYY-MM-DD
  priorAuthorization: boolean;
  status: ClaimStatus;
  historyLog: AuditActionLog[];
}

export interface FlagItem {
  code: string;
  module: AnomalyModule;
  severity: 'critical' | 'high' | 'medium' | 'low';
  title: string;
  description: string;
  policyRef?: string;
  evidence: Record<string, string | number | boolean>;
}

export interface DuplicateMatchDetail {
  matchedClaimId: string;
  similarity: number; // 0 to 100
  matchType: 'exact' | 'near_duplicate' | 'unbundled';
  matchedFields: string[];
  differingFields: string[];
  dayDifference: number;
  amountDifference: number;
  matchedClaim: Claim;
}

export interface PeerBenchmark {
  specialty: string;
  peerMeanAmount: number;
  peerStdDev: number;
  zScore: number;
  percentile: number;
  specialtyAvgMonthlyVolume: number;
  providerMonthlyVolume: number;
  peerDenialRate: number;
  providerDenialRate: number;
}

export interface ClinicalCheck {
  isConsistent: boolean;
  compatibilityScore: number; // 0 to 100
  clinicalRationale: string;
  guidelineRef: string;
  cciEditFound: boolean;
  cciDetail?: string;
}

export interface ShapAttribution {
  feature: string;
  value: string;
  contribution: number; // point addition/subtraction
  description: string;
  category: 'amount' | 'provider' | 'coding' | 'utilization' | 'history' | 'base';
}

export interface LimeExplanation {
  intercept: number;
  localPrediction: number;
  topRule: string;
  counterfactual: string;
}

export interface NaturalLanguageSummary {
  headline: string;
  primaryDriver: string;
  secondaryDriver: string;
  providerContext: string;
  recommendedAction: string;
  regulatoryCitation: string;
}

export interface DetectionResult {
  compositeRiskScore: number; // 0 to 100
  riskTier: RiskTier;
  financialExposure: number; // INR
  layers: {
    anomalyScore: number; // 0 to 100
    duplicateScore: number; // 0 to 100
    codingErrorScore: number; // 0 to 100
    providerRiskScore: number; // 0 to 100
  };
  flags: FlagItem[];
  duplicateMatch?: DuplicateMatchDetail;
  peerBenchmark: PeerBenchmark;
  clinicalCheck: ClinicalCheck;
  shapAttribution: ShapAttribution[];
  limeExplanation: LimeExplanation;
  naturalLanguageSummary: NaturalLanguageSummary;
}

export interface PolicyRule {
  id: string;
  name: string;
  category: AnomalyModule;
  description: string;
  threshold: string;
  policyCitation: string;
  enabled: boolean;
  severity: 'critical' | 'high' | 'medium';
}
