import React, { useState } from 'react';
import { Claim, DetectionResult, UserProfile } from '../types';
import { DIAGNOSES_DATABASE, PROCEDURES_DATABASE } from '../engine/knowledgeGraph';
import { runDetectionEngine, DEFAULT_POLICY_RULES } from '../engine/detectionEngine';
import {
  Building2,
  Stethoscope,
  CheckCircle2,
  AlertTriangle,
  Upload,
  FileText,
  Clock,
  ArrowRight,
  ShieldCheck,
  Search,
  Sparkles,
  Send,
  HelpCircle,
} from 'lucide-react';

interface ProviderPortalProps {
  currentUser: UserProfile;
  claims: Claim[];
  detectionResults: Map<string, DetectionResult>;
  onIngestClaim: (newClaim: Claim) => void;
  onRespondRfi: (claimId: string, responseNote: string) => void;
  currency: 'INR' | 'USD';
  exchangeRate: number;
}

export const ProviderPortal: React.FC<ProviderPortalProps> = ({
  currentUser,
  claims,
  detectionResults,
  onIngestClaim,
  onRespondRfi,
  currency,
  exchangeRate,
}) => {
  const [activeTab, setActiveTab] = useState<'tracker' | 'precheck' | 'rfi'>('tracker');
  const [selectedClaimForRfi, setSelectedClaimForRfi] = useState<Claim | null>(null);
  const [rfiNote, setRfiNote] = useState('');
  const [rfiFileAttached, setRfiFileAttached] = useState(false);

  // Pre-Check Form state
  const [prePatientId, setPrePatientId] = useState('P-10842');
  const [prePatientName, setPrePatientName] = useState('Devika Rao');
  const [preDiagnosis, setPreDiagnosis] = useState('I25.10'); // Default compatible
  const [preProcedure, setPreProcedure] = useState('33533');
  const [preAmount, setPreAmount] = useState<number>(310000);
  const [preServiceDate, setPreServiceDate] = useState('2026-06-12');
  const [prePriorAuth, setPrePriorAuth] = useState(true);
  const [preCheckResult, setPreCheckResult] = useState<DetectionResult | null>(null);

  const formatMoney = (inrVal: number) => {
    if (currency === 'USD') {
      const usdVal = Math.round(inrVal / exchangeRate);
      return `$${usdVal.toLocaleString('en-US')}`;
    }
    return `₹${inrVal.toLocaleString('en-IN')}`;
  };

  // Hospital's claims (matching HSP-101 or Apex)
  const hospitalClaims = claims.filter(
    (c) =>
      c.providerId === currentUser.facilityId ||
      c.providerName.toLowerCase().includes('apex') ||
      currentUser.facilityId === undefined
  );

  const rfiPendingClaims = hospitalClaims.filter(
    (c) => c.status === 'rfi_requested' || c.status === 'investigating'
  );

  // Run instant AI pre-check on draft claim
  const handleRunPreCheck = () => {
    const diag = DIAGNOSES_DATABASE[preDiagnosis];
    const proc = PROCEDURES_DATABASE[preProcedure];

    const draftClaim: Claim = {
      id: `DRAFT-${Math.floor(1000 + Math.random() * 9000)}`,
      patientId: prePatientId,
      patientName: prePatientName,
      patientAge: 52,
      patientGender: 'F',
      providerId: currentUser.facilityId || 'HSP-101',
      providerName: currentUser.organization,
      providerSpecialty: proc ? proc.specialty : 'General Medicine',
      location: 'Bangalore',
      diagnosisCode: preDiagnosis,
      diagnosisDesc: diag ? diag.name : 'Primary Diagnosis',
      procedureCode: preProcedure,
      procedureDesc: proc ? proc.name : 'Surgical Procedure',
      units: 1,
      billedAmount: preAmount,
      serviceDate: preServiceDate,
      submissionDate: new Date().toISOString().split('T')[0],
      priorAuthorization: prePriorAuth,
      status: 'pending_review',
      historyLog: [],
    };

    const res = runDetectionEngine(draftClaim, claims, DEFAULT_POLICY_RULES);
    setPreCheckResult(res);
  };

  // Submit verified claim to insurer pipeline
  const handleSubmitVerifiedClaim = () => {
    if (!preCheckResult) return;
    const diag = DIAGNOSES_DATABASE[preDiagnosis];
    const proc = PROCEDURES_DATABASE[preProcedure];
    const newId = `CLM-${Math.floor(10000 + Math.random() * 90000)}`;

    const newClaim: Claim = {
      id: newId,
      patientId: prePatientId,
      patientName: prePatientName,
      patientAge: 52,
      patientGender: 'F',
      providerId: currentUser.facilityId || 'HSP-101',
      providerName: currentUser.organization,
      providerSpecialty: proc ? proc.specialty : 'General Medicine',
      location: 'Bangalore',
      diagnosisCode: preDiagnosis,
      diagnosisDesc: diag ? diag.name : 'Primary Diagnosis',
      procedureCode: preProcedure,
      procedureDesc: proc ? proc.name : 'Surgical Procedure',
      units: 1,
      billedAmount: preAmount,
      serviceDate: preServiceDate,
      submissionDate: new Date().toISOString().split('T')[0],
      priorAuthorization: prePriorAuth,
      status: 'pending_review',
      historyLog: [
        {
          id: `LOG-${Date.now()}`,
          action: 'Provider Pre-Validated Submission',
          timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
          note: `Submitted via Hospital Provider Portal by ${currentUser.name} after passing pre-check.`,
          actor: currentUser.name,
        },
      ],
    };

    onIngestClaim(newClaim);
    setPreCheckResult(null);
    setActiveTab('tracker');
  };

  const handleSendRfi = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedClaimForRfi) return;
    const fullNote = `${rfiNote.trim()} ${rfiFileAttached ? '(Attachment: Verified Operative Notes & Pathology Report attached.pdf)' : ''}`;
    onRespondRfi(selectedClaimForRfi.id, fullNote);
    setSelectedClaimForRfi(null);
    setRfiNote('');
    setRfiFileAttached(false);
  };

  return (
    <div className="space-y-6">
      {/* Hospital Identity Header Card */}
      <div className="p-6 rounded-2xl border border-slate-800 bg-slate-900/80 shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-800">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-xl bg-emerald-950/80 border border-emerald-700/60 flex items-center justify-center text-emerald-400 shadow-sm">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white">{currentUser.organization}</h2>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                  ID: {currentUser.facilityId || 'HSP-101'}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Hospital Billing & Clinical Compliance Portal · User:{' '}
                <strong className="text-slate-200">{currentUser.name}</strong> ({currentUser.department})
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('precheck')}
              className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Pre-Validate New Claim</span>
            </button>
          </div>
        </div>

        {/* Hospital Metrics Strip */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-5 text-xs">
          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-slate-400 block">Submitted Claims</span>
            <span className="text-2xl font-bold font-mono text-white mt-1 block">
              {hospitalClaims.length}
            </span>
            <span className="text-[11px] text-slate-500">In current billing period</span>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-emerald-400 block font-medium">Clean Approval Rate</span>
            <span className="text-2xl font-bold font-mono text-emerald-400 mt-1 block">
              82.4%
            </span>
            <span className="text-[11px] text-slate-500">First-pass straight-through</span>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-amber-400 block font-medium">Pending RFI Requests</span>
            <span className="text-2xl font-bold font-mono text-amber-400 mt-1 block">
              {rfiPendingClaims.length}
            </span>
            <span className="text-[11px] text-slate-500">Requires medical records</span>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-indigo-400 block font-medium">Pre-Submission Quality Index</span>
            <span className="text-2xl font-bold font-mono text-indigo-400 mt-1 block">
              96.8 / 100
            </span>
            <span className="text-[11px] text-slate-500">Low duplicate risk rating</span>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs for Provider */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 text-xs">
        <button
          onClick={() => setActiveTab('tracker')}
          className={`px-3.5 py-1.5 rounded-lg font-medium transition-colors ${
            activeTab === 'tracker'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Hospital Claims Status ({hospitalClaims.length})
        </button>
        <button
          onClick={() => setActiveTab('precheck')}
          className={`px-3.5 py-1.5 rounded-lg font-medium transition-colors ${
            activeTab === 'precheck'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          AI Pre-Submission Validator
        </button>
        <button
          onClick={() => setActiveTab('rfi')}
          className={`px-3.5 py-1.5 rounded-lg font-medium transition-colors ${
            activeTab === 'rfi'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Insurer RFI Inquiries ({rfiPendingClaims.length})
        </button>
      </div>

      {/* Tab 1: Claims Tracker for this Hospital */}
      {activeTab === 'tracker' && (
        <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-900/60 shadow-lg">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950/80 text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
                  <th className="py-3 px-4">Claim ID & Date</th>
                  <th className="py-3 px-4">Patient</th>
                  <th className="py-3 px-4">Diagnosis ↔ Procedure</th>
                  <th className="py-3 px-4 text-right">Billed Amount</th>
                  <th className="py-3 px-4">Adjudication Status</th>
                  <th className="py-3 px-4">AI Risk Tier</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {hospitalClaims.map((claim) => {
                  const res = detectionResults.get(claim.id);
                  const isRfi = claim.status === 'rfi_requested';

                  return (
                    <tr key={claim.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-mono font-semibold text-slate-200">{claim.id}</div>
                        <div className="text-[11px] text-slate-500 font-mono">{claim.serviceDate}</div>
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-200">{claim.patientName}</div>
                        <div className="text-[11px] text-slate-500 font-mono">{claim.patientId}</div>
                      </td>

                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1.5 font-mono">
                          <span className="text-indigo-300 font-semibold">{claim.diagnosisCode}</span>
                          <span className="text-slate-600">↔</span>
                          <span className="text-slate-300">{claim.procedureCode}</span>
                        </div>
                        <div className="text-[11px] text-slate-400 truncate max-w-[200px]" title={claim.procedureDesc}>
                          {claim.procedureDesc}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-right font-mono font-semibold text-slate-200 tabular-nums">
                        {formatMoney(claim.billedAmount)}
                      </td>

                      <td className="py-3 px-4">
                        <span
                          className={`font-mono text-xs px-2 py-0.5 rounded border capitalize ${
                            claim.status === 'dismissed_clean'
                              ? 'bg-emerald-950/80 text-emerald-300 border-emerald-800'
                              : claim.status === 'confirmed_fraud'
                              ? 'bg-rose-950/80 text-rose-300 border-rose-800'
                              : claim.status === 'rfi_requested'
                              ? 'bg-amber-950/80 text-amber-300 border-amber-800'
                              : 'bg-slate-800 text-slate-300 border-slate-700'
                          }`}
                        >
                          {claim.status.replace('_', ' ')}
                        </span>
                      </td>

                      <td className="py-3 px-4">
                        {res && (
                          <div className="flex items-center gap-2">
                            <span
                              className={`font-mono font-bold text-xs px-2 py-0.5 rounded border ${
                                res.compositeRiskScore >= 70
                                  ? 'bg-rose-950/60 text-rose-300 border-rose-800'
                                  : res.compositeRiskScore >= 40
                                  ? 'bg-amber-950/60 text-amber-300 border-amber-800'
                                  : 'bg-emerald-950/60 text-emerald-300 border-emerald-800'
                              }`}
                            >
                              {res.compositeRiskScore}/100
                            </span>
                          </div>
                        )}
                      </td>

                      <td className="py-3 px-4 text-right">
                        {isRfi ? (
                          <button
                            onClick={() => {
                              setSelectedClaimForRfi(claim);
                              setActiveTab('rfi');
                            }}
                            className="px-2.5 py-1 text-xs font-semibold rounded bg-amber-600 hover:bg-amber-500 text-white transition-colors"
                          >
                            Respond to RFI
                          </button>
                        ) : (
                          <span className="text-[11px] text-slate-500">In adjudication</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: AI Pre-Submission Validator */}
      {activeTab === 'precheck' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Draft Form */}
          <div className="p-6 rounded-2xl border border-slate-800 bg-slate-900/60 space-y-4 text-xs">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-semibold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>Pre-Submission Claim Validator</span>
              </h4>
              <span className="text-[11px] text-slate-400">Catch errors before filing</span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">Patient ID & Name</label>
                <input
                  type="text"
                  value={prePatientName}
                  onChange={(e) => setPrePatientName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Treatment Date</label>
                <input
                  type="date"
                  value={preServiceDate}
                  onChange={(e) => setPreServiceDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-mono"
                />
              </div>

              <div className="col-span-2">
                <label className="text-slate-400 block mb-1">Primary ICD-10 Diagnosis</label>
                <select
                  value={preDiagnosis}
                  onChange={(e) => setPreDiagnosis(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-mono"
                >
                  {Object.values(DIAGNOSES_DATABASE).map((d) => (
                    <option key={d.code} value={d.code}>
                      {d.code} - {d.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="col-span-2">
                <label className="text-slate-400 block mb-1">Billed Procedure (CPT Code)</label>
                <select
                  value={preProcedure}
                  onChange={(e) => setPreProcedure(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-mono"
                >
                  {Object.values(PROCEDURES_DATABASE).map((p) => (
                    <option key={p.code} value={p.code}>
                      {p.code} - {p.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Billed Amount (INR ₹)</label>
                <input
                  type="number"
                  value={preAmount}
                  onChange={(e) => setPreAmount(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-mono tabular-nums font-semibold"
                />
              </div>

              <div className="flex items-center gap-2 pt-6">
                <input
                  type="checkbox"
                  id="preAuthCheck"
                  checked={prePriorAuth}
                  onChange={(e) => setPrePriorAuth(e.target.checked)}
                  className="rounded border-slate-800 text-emerald-600 focus:ring-0"
                />
                <label htmlFor="preAuthCheck" className="text-slate-300 cursor-pointer">
                  Prior Authorization Verified
                </label>
              </div>
            </div>

            <button
              onClick={handleRunPreCheck}
              className="w-full py-2.5 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 shadow transition-colors flex items-center justify-center gap-2"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Run Pre-Submission AI Audit</span>
            </button>
          </div>

          {/* Pre-Check AI Report */}
          <div className="p-6 rounded-2xl border border-slate-800 bg-slate-900/60 space-y-4">
            <h4 className="text-sm font-semibold text-white">Pre-Check Audit Result</h4>

            {preCheckResult ? (
              <div className="space-y-4 text-xs">
                <div
                  className={`p-4 rounded-xl border ${
                    preCheckResult.compositeRiskScore < 40
                      ? 'border-emerald-900/80 bg-emerald-950/30 text-emerald-300'
                      : 'border-rose-900/80 bg-rose-950/30 text-rose-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-sm">
                      {preCheckResult.compositeRiskScore < 40
                        ? 'Passed: Cleared for Direct Adjudication'
                        : 'Alert: Likely Insurer Rejection or Investigation'}
                    </span>
                    <span className="font-mono font-bold text-base">
                      Risk Score: {preCheckResult.compositeRiskScore} / 100
                    </span>
                  </div>
                  <p className="mt-1 text-slate-300">
                    {preCheckResult.naturalLanguageSummary.headline}
                  </p>
                </div>

                {/* Flags if any */}
                {preCheckResult.flags.length > 0 && (
                  <div className="space-y-2">
                    <span className="text-slate-400 font-medium">Issues to resolve prior to filing:</span>
                    {preCheckResult.flags.map((f, i) => (
                      <div key={i} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                        <strong className="text-rose-400 block">{f.title}</strong>
                        <p className="text-slate-400 mt-0.5">{f.description}</p>
                      </div>
                    ))}
                  </div>
                )}

                <div className="pt-2">
                  <button
                    onClick={handleSubmitVerifiedClaim}
                    className="w-full py-2.5 rounded-xl text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 shadow-md transition-colors flex items-center justify-center gap-2"
                  >
                    <span>Confirm & Transmit Claim to Insurer</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ) : (
              <div className="py-16 text-center text-slate-500 text-xs">
                <Sparkles className="w-6 h-6 mx-auto mb-2 text-slate-600" />
                <span>Fill out the draft claim parameters and click "Run Pre-Submission AI Audit"</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 3: RFI Inquiries Drawer / View */}
      {activeTab === 'rfi' && (
        <div className="space-y-4">
          <div className="p-5 rounded-2xl border border-slate-800 bg-slate-900/60">
            <h4 className="text-sm font-semibold text-white mb-1">
              Insurer Requests for Information (RFI)
            </h4>
            <p className="text-xs text-slate-400">
              Claims placed under investigation where the insurer has requested supporting clinical notes, operative summaries, or anesthesia records.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {rfiPendingClaims.map((claim) => (
              <div key={claim.id} className="p-5 rounded-xl border border-amber-900/60 bg-amber-950/20 space-y-3 text-xs">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="font-mono font-bold text-amber-300 text-sm">{claim.id}</span>
                    <span className="text-slate-400 block mt-0.5">Patient: {claim.patientName} ({claim.patientId})</span>
                  </div>
                  <span className="font-mono font-semibold text-white tabular-nums">
                    {formatMoney(claim.billedAmount)}
                  </span>
                </div>

                <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800 text-[11px] text-slate-300">
                  <span className="text-amber-400 font-semibold block">Insurer Inquiry:</span>
                  <p className="mt-0.5">
                    {claim.historyLog[0]?.note || 'Provide itemized surgical log and pathology report verifying medical necessity.'}
                  </p>
                </div>

                <button
                  onClick={() => setSelectedClaimForRfi(claim)}
                  className="w-full py-2 rounded-lg text-xs font-semibold text-white bg-amber-600 hover:bg-amber-500 shadow transition-colors flex items-center justify-center gap-2"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Attach Documentation & Respond</span>
                </button>
              </div>
            ))}
          </div>

          {/* RFI Response Modal */}
          {selectedClaimForRfi && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
              <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 text-xs">
                <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                  <h3 className="font-semibold text-white text-sm">
                    Respond to Insurer RFI · {selectedClaimForRfi.id}
                  </h3>
                  <button
                    onClick={() => setSelectedClaimForRfi(null)}
                    className="text-slate-400 hover:text-white"
                  >
                    ✕
                  </button>
                </div>

                <form onSubmit={handleSendRfi} className="space-y-4">
                  <div>
                    <label className="text-slate-300 block mb-1 font-medium">
                      Physician / Revenue Cycle Response Note
                    </label>
                    <textarea
                      required
                      value={rfiNote}
                      onChange={(e) => setRfiNote(e.target.value)}
                      placeholder="Explain clinical necessity, secondary complications, or clarify the billed procedural modifiers..."
                      rows={4}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div className="p-3 rounded-lg border border-slate-800 bg-slate-950 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-indigo-400" />
                      <span className="text-slate-300">
                        {rfiFileAttached ? 'Operative_Record_Verified.pdf' : 'Attach Medical Document (PDF)'}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setRfiFileAttached(!rfiFileAttached)}
                      className={`px-2.5 py-1 rounded text-[11px] font-medium border transition-colors ${
                        rfiFileAttached
                          ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                          : 'border-slate-700 text-slate-300 hover:text-white'
                      }`}
                    >
                      {rfiFileAttached ? 'Attached ✓' : 'Browse File'}
                    </button>
                  </div>

                  <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                    <button
                      type="button"
                      onClick={() => setSelectedClaimForRfi(null)}
                      className="px-3.5 py-2 text-slate-400 hover:text-white"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 rounded-lg text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 shadow"
                    >
                      Transmit Response to Insurer SIU
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
