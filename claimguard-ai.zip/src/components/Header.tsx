import React from 'react';
import { ShieldAlert, Plus, IndianRupee, DollarSign, LogOut, User, Building2, Stethoscope } from 'lucide-react';
import { UserProfile } from '../types';

export type NavTab = 'queue' | 'dossier' | 'sandbox' | 'analytics' | 'rules' | 'provider_portal';

interface HeaderProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  currency: 'INR' | 'USD';
  setCurrency: (c: 'INR' | 'USD') => void;
  onOpenNewClaimModal: () => void;
  pendingReviewCount: number;
  currentUser: UserProfile;
  onLogout: () => void;
  onSwitchPortal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  currency,
  setCurrency,
  onOpenNewClaimModal,
  pendingReviewCount,
  currentUser,
  onLogout,
  onSwitchPortal,
}) => {
  const isCompany = currentUser.portalType === 'company';
  return (
    <header className="border-b border-slate-800 bg-slate-950/90 backdrop-blur sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Brand Wordmark (Single element, no adjacent pill clutter) */}
          <div className="flex items-center gap-2.5 shrink-0">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-indigo-600 to-indigo-400 flex items-center justify-center text-white shadow-sm">
              <ShieldAlert className="w-4 h-4" />
            </div>
            <span className="text-base font-bold tracking-tight text-white whitespace-nowrap">
              ClaimGuard AI
            </span>
          </div>

          {/* Zone 2: Single-line clean navigation links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
            {isCompany ? (
              <>
                <button
                  onClick={() => setActiveTab('queue')}
                  className={`transition-colors whitespace-nowrap py-1 relative ${
                    activeTab === 'queue'
                      ? 'text-white font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Workbench Queue
                  {pendingReviewCount > 0 && (
                    <span className="ml-1.5 text-[11px] font-mono text-amber-400 bg-amber-950/80 px-1.5 py-0.2 rounded border border-amber-800/80">
                      {pendingReviewCount}
                    </span>
                  )}
                  {activeTab === 'queue' && (
                    <span className="absolute bottom-[-17px] left-0 right-0 h-0.5 bg-indigo-500 rounded-full" />
                  )}
                </button>

                <button
                  onClick={() => setActiveTab('dossier')}
                  className={`transition-colors whitespace-nowrap py-1 relative ${
                    activeTab === 'dossier'
                      ? 'text-white font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Evidence Dossier
                  {activeTab === 'dossier' && (
                    <span className="absolute bottom-[-17px] left-0 right-0 h-0.5 bg-indigo-500 rounded-full" />
                  )}
                </button>

                <button
                  onClick={() => setActiveTab('sandbox')}
                  className={`transition-colors whitespace-nowrap py-1 relative ${
                    activeTab === 'sandbox'
                      ? 'text-white font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Batch Sandbox
                  {activeTab === 'sandbox' && (
                    <span className="absolute bottom-[-17px] left-0 right-0 h-0.5 bg-indigo-500 rounded-full" />
                  )}
                </button>

                <button
                  onClick={() => setActiveTab('analytics')}
                  className={`transition-colors whitespace-nowrap py-1 relative ${
                    activeTab === 'analytics'
                      ? 'text-white font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Model Analytics
                  {activeTab === 'analytics' && (
                    <span className="absolute bottom-[-17px] left-0 right-0 h-0.5 bg-indigo-500 rounded-full" />
                  )}
                </button>

                <button
                  onClick={() => setActiveTab('rules')}
                  className={`transition-colors whitespace-nowrap py-1 relative ${
                    activeTab === 'rules'
                      ? 'text-white font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Policy Rules
                  {activeTab === 'rules' && (
                    <span className="absolute bottom-[-17px] left-0 right-0 h-0.5 bg-indigo-500 rounded-full" />
                  )}
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => setActiveTab('provider_portal')}
                  className={`transition-colors whitespace-nowrap py-1 relative ${
                    activeTab === 'provider_portal'
                      ? 'text-white font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Hospital Claims Tracker
                  {activeTab === 'provider_portal' && (
                    <span className="absolute bottom-[-17px] left-0 right-0 h-0.5 bg-emerald-500 rounded-full" />
                  )}
                </button>

                <button
                  onClick={() => setActiveTab('dossier')}
                  className={`transition-colors whitespace-nowrap py-1 relative ${
                    activeTab === 'dossier'
                      ? 'text-white font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Claim Audit Dossier
                  {activeTab === 'dossier' && (
                    <span className="absolute bottom-[-17px] left-0 right-0 h-0.5 bg-emerald-500 rounded-full" />
                  )}
                </button>

                <button
                  onClick={() => setActiveTab('sandbox')}
                  className={`transition-colors whitespace-nowrap py-1 relative ${
                    activeTab === 'sandbox'
                      ? 'text-white font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Pre-Submission Sandbox
                  {activeTab === 'sandbox' && (
                    <span className="absolute bottom-[-17px] left-0 right-0 h-0.5 bg-emerald-500 rounded-full" />
                  )}
                </button>
              </>
            )}
          </nav>

          {/* Zone 3: Currency + User Profile Chip + Logout */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="flex items-center bg-slate-900 border border-slate-800 rounded-lg p-0.5 text-xs">
              <button
                onClick={() => setCurrency('INR')}
                title="View figures in INR (₹)"
                className={`px-2 py-1 rounded flex items-center gap-1 transition-colors ${
                  currency === 'INR'
                    ? 'bg-slate-800 text-white font-medium'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <IndianRupee className="w-3 h-3" />
                <span>INR</span>
              </button>
              <button
                onClick={() => setCurrency('USD')}
                title="View figures in USD ($)"
                className={`px-2 py-1 rounded flex items-center gap-1 transition-colors ${
                  currency === 'USD'
                    ? 'bg-slate-800 text-white font-medium'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <DollarSign className="w-3 h-3" />
                <span>USD</span>
              </button>
            </div>

            {/* User Profile Chip */}
            <div className="hidden sm:flex items-center gap-2 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-xs">
              <div
                className={`w-5 h-5 rounded-md flex items-center justify-center text-white ${
                  isCompany ? 'bg-indigo-600' : 'bg-emerald-600'
                }`}
              >
                {isCompany ? (
                  <Building2 className="w-3 h-3" />
                ) : (
                  <Stethoscope className="w-3 h-3" />
                )}
              </div>
              <div className="text-left">
                <span className="font-semibold text-slate-200 block truncate max-w-[120px]">
                  {currentUser.name}
                </span>
                <span className="text-[10px] text-slate-500 block truncate max-w-[120px]">
                  {currentUser.organization}
                </span>
              </div>
            </div>

            <button
              onClick={onSwitchPortal}
              title={`Switch to ${isCompany ? 'Hospital & Clinic' : 'Insurer Company'} Portal`}
              className="hidden lg:flex px-2 py-1.5 text-[11px] font-medium text-slate-400 hover:text-white rounded border border-slate-800 hover:bg-slate-800 transition-colors"
            >
              Switch Portal
            </button>

            <button
              onClick={onLogout}
              title="Sign Out"
              className="p-2 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-slate-900 border border-transparent hover:border-slate-800 transition-colors"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
