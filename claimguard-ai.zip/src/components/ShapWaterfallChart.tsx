import React, { useState } from 'react';
import { ShapAttribution } from '../types';

interface ShapWaterfallChartProps {
  attributions: ShapAttribution[];
  compositeRiskScore: number;
  baseBaseline?: number;
}

export const ShapWaterfallChart: React.FC<ShapWaterfallChartProps> = ({
  attributions,
  compositeRiskScore,
  baseBaseline = 12,
}) => {
  const [viewMode, setViewMode] = useState<'waterfall' | 'bars'>('waterfall');
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  // Compute waterfall running totals
  let runningTotal = baseBaseline;
  const waterfallSteps = attributions.map((attr) => {
    const startVal = runningTotal;
    runningTotal = Math.max(0, runningTotal + attr.contribution);
    return {
      ...attr,
      startVal,
      endVal: runningTotal,
    };
  });

  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-5">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div>
          <h4 className="text-sm font-semibold text-white flex items-center gap-2">
            <span>Explainable AI: SHAP Feature Attribution</span>
            <span className="text-xs text-slate-400 font-normal">
              (SHapley Additive exPlanations)
            </span>
          </h4>
          <p className="text-xs text-slate-400 mt-0.5">
            Quantifies the exact point contribution of each claim feature toward the final risk score of{' '}
            <strong className="text-white font-mono">{compositeRiskScore}/100</strong>.
          </p>
        </div>

        <div className="flex items-center gap-1 bg-slate-800/80 p-1 rounded-lg border border-slate-700/60 text-xs">
          <button
            onClick={() => setViewMode('waterfall')}
            className={`px-2.5 py-1 rounded transition-colors whitespace-nowrap ${
              viewMode === 'waterfall'
                ? 'bg-indigo-600 text-white font-medium shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Waterfall Step View
          </button>
          <button
            onClick={() => setViewMode('bars')}
            className={`px-2.5 py-1 rounded transition-colors whitespace-nowrap ${
              viewMode === 'bars'
                ? 'bg-indigo-600 text-white font-medium shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Relative Weight Bars
          </button>
        </div>
      </div>

      {viewMode === 'waterfall' ? (
        <div className="space-y-3">
          {/* Baseline Step */}
          <div className="flex items-center justify-between text-xs py-1.5 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-sm bg-slate-500"></span>
              <span className="font-medium text-slate-300">Population Prior Baseline</span>
              <span className="text-slate-500">(All clean claims starting point)</span>
            </div>
            <span className="font-mono text-slate-400 tabular-nums">+{baseBaseline} pts</span>
          </div>

          {/* Feature Steps */}
          {waterfallSteps.map((step, idx) => {
            const isPositive = step.contribution >= 0;
            const barWidthPct = Math.min(100, Math.max(8, (Math.abs(step.contribution) / 40) * 100));

            return (
              <div
                key={idx}
                onMouseEnter={() => setHoveredIdx(idx)}
                onMouseLeave={() => setHoveredIdx(null)}
                className={`p-2.5 rounded-lg transition-colors border ${
                  hoveredIdx === idx
                    ? 'bg-slate-800/90 border-slate-700'
                    : 'bg-slate-950/40 border-slate-800/60'
                }`}
              >
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <div className="flex items-center gap-2">
                    <span
                      className={`w-2.5 h-2.5 rounded-sm ${
                        isPositive ? 'bg-rose-500' : 'bg-emerald-500'
                      }`}
                    ></span>
                    <span className="font-semibold text-slate-200">{step.feature}</span>
                    <span className="text-slate-400 font-mono text-[11px] bg-slate-800 px-1.5 py-0.5 rounded">
                      {step.value}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 font-mono tabular-nums">
                    <span
                      className={`font-semibold ${
                        isPositive ? 'text-rose-400' : 'text-emerald-400'
                      }`}
                    >
                      {isPositive ? `+${step.contribution}` : `${step.contribution}`} pts
                    </span>
                    <span className="text-slate-500 text-[11px]">
                      → {step.endVal} pts
                    </span>
                  </div>
                </div>

                {/* Progress bar container */}
                <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden flex">
                  <div
                    className={`h-full transition-all duration-300 rounded-full ${
                      isPositive
                        ? 'bg-gradient-to-r from-amber-500 to-rose-500'
                        : 'bg-emerald-500'
                    }`}
                    style={{ width: `${barWidthPct}%` }}
                  />
                </div>

                <p className="text-[11px] text-slate-400 mt-1.5">{step.description}</p>
              </div>
            );
          })}

          {/* Final Composite Result */}
          <div className="flex items-center justify-between text-xs pt-3 border-t border-slate-800 font-medium">
            <span className="text-slate-200 font-semibold">Total Composite Score (Σ SHAP + Baseline)</span>
            <div className="flex items-center gap-2 font-mono">
              <span className="text-slate-400 text-[11px]">(Calculated)</span>
              <span
                className={`text-sm font-bold tabular-nums px-2 py-0.5 rounded ${
                  compositeRiskScore >= 70
                    ? 'text-rose-400 bg-rose-950/60 border border-rose-800/80'
                    : compositeRiskScore >= 40
                    ? 'text-amber-400 bg-amber-950/60 border border-amber-800/80'
                    : 'text-emerald-400 bg-emerald-950/60 border border-emerald-800/80'
                }`}
              >
                {compositeRiskScore} / 100
              </span>
            </div>
          </div>
        </div>
      ) : (
        /* Feature Importance Bar View */
        <div className="space-y-3">
          {attributions.map((attr, idx) => {
            const isPositive = attr.contribution >= 0;
            const barWidthPct = Math.min(100, Math.max(5, (Math.abs(attr.contribution) / 35) * 100));

            return (
              <div key={idx} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-medium">{attr.feature}</span>
                  <span
                    className={`font-mono tabular-nums ${
                      isPositive ? 'text-rose-400' : 'text-emerald-400'
                    }`}
                  >
                    {isPositive ? `+${attr.contribution}` : attr.contribution} SHAP
                  </span>
                </div>
                <div className="w-full bg-slate-950 rounded h-3 overflow-hidden flex border border-slate-800">
                  <div
                    className={`h-full ${
                      isPositive ? 'bg-rose-500' : 'bg-emerald-500'
                    }`}
                    style={{ width: `${barWidthPct}%` }}
                  />
                </div>
                <div className="flex justify-between text-[11px] text-slate-500">
                  <span>{attr.value}</span>
                  <span>{attr.description}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
