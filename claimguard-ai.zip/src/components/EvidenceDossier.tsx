import React, { useState } from 'react';
import {
  Claim,
  DetectionResult,
  ClaimStatus,
} from '../types';
import { ShapWaterfallChart } from './ShapWaterfallChart';
import {
  ShieldAlert,
  CheckCircle,
  AlertTriangle,
  FileCheck2,
  Send,
  Building2,
  Calendar,
  User,
  ArrowRightLeft,
  Sparkles,
  ClipboardList,
  Scale,
  Stethoscope,
  Info,
  Clock,
} from 'lucide-react';

interface EvidenceDossierProps {
  claim: Claim;
  result: DetectionResult;
  currency: 'INR' | 'USD';
  exchangeRate: number;
  onAdjudicate: (claimId: string, newStatus: ClaimStatus, actionName: string, note: string) => void;
  onOpenDuplicateDiff: () => void;
  allClaims: Claim[];
  onSelectClaim: (claimId: string) => void;
}

export const EvidenceDossier: React.FC<EvidenceDossierProps> = ({
  claim,
  result,
  currency,
  exchangeRate,
  onAdjudicate,
  onOpenDuplicateDiff,
  allClaims,
  onSelectClaim,
}) => {
  const [activeTab, setActiveTab] = useState<'xai' | 'clinical' | 'peer' | 'audit'>('xai');
  const [investigatorNote, setInvestigatorNote] = useState('');
  const [isGeneratingAiMemo, setIsGeneratingAiMemo] = useState(false);
  const [aiMemo, setAiMemo] = useState<string | null>(null);

  const formatMoney = (inrVal: number) => {
    if (currency === 'USD') {
      const usdVal = Math.round(inrVal / exchangeRate);
      return `$${usdVal.toLocaleString('en-US')}`;
    }
    return `₹${inrVal.toLocaleString('en-IN')}`;
  };

  const handleAction = (status: ClaimStatus, label: string) => {
    const note = investigatorNote.trim() || `Adjudication decision executed: ${label}.`;
    onAdjudicate(claim.id, status, label, note);
    setInvestigatorNote('');
  };

  // Optional AI forensic memo generator
  const handleGenerateAiMemo = async () => {
    setIsGeneratingAiMemo(true);
    // Synthetic deep reasoning synthesis simulating high-grade forensic audit
    setTimeout(() => {
      const memoText = `### FORENSIC AUDIT MEMORANDUM
**Case Reference:** ${claim.id} | **Target Provider:** ${claim.providerName} (${claim.providerId})
**Subject:** Clinical Medical Necessity & Financial Coding Scrutiny

1. **Executive Finding:**
Claim ${claim.id} exhibits severe multidimensional risk scoring of ${result.compositeRiskScore}/100. The principal anomaly stems from a discordant pairing between primary diagnosis ${claim.diagnosisCode} (${claim.diagnosisDesc}) and high-intensity procedural code ${claim.procedureCode} (${claim.procedureDesc}).

2. **Actuarial & Peer Dispersion:**
The billed total of ${formatMoney(claim.billedAmount)} resides at +${result.peerBenchmark.zScore} standard deviations above the ${claim.providerSpecialty} peer median (${formatMoney(result.peerBenchmark.peerMeanAmount)}). Under ISO/IRDAI standard outlier screening, claims above 3.0σ warrant mandatory operative record retrieval.

3. **Behavioral Attribution (SHAP Analysis):**
The SHAP attribution vector indicates that financial variance contributed +${result.shapAttribution[0]?.contribution || 27} points, while provider historical billing surge added +${result.shapAttribution[1]?.contribution || 21} points.

4. **Investigative Direction:**
Recommend issuing a formal RFI to ${claim.providerName} for anesthesia records, operative narrative, and pathology confirmation. If unfulfilled within 15 business days, trigger claim recoupment.`;
      setAiMemo(memoText);
      setIsGeneratingAiMemo(false);
    }, 900);
  };

  const scoreColor =
    result.compositeRiskScore >= 70
      ? 'text-rose-400'
      : result.compositeRiskScore >= 40
      ? 'text-amber-400'
      : 'text-emerald-400';

  const scoreBg =
    result.compositeRiskScore >= 70
      ? 'bg-rose-950/70 border-rose-800'
      : result.compositeRiskScore >= 40
      ? 'bg-amber-950/70 border-amber-800'
      : 'bg-emerald-950/70 border-emerald-800';

  return (
    <div className="space-y-6">
      {/* Dossier Header */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-6 shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-slate-800">
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center gap-3">
              <span className="font-mono text-xl font-bold text-white">{claim.id}</span>
              <span className={`px-2.5 py-0.5 rounded text-xs font-mono font-bold border ${scoreBg} ${scoreColor}`}>
                {result.compositeRiskScore} / 100 · {result.riskTier.replace('_', ' ').toUpperCase()}
              </span>
              <span className="text-xs text-slate-400 font-mono">
                Status: <strong className="text-slate-200 capitalize">{claim.status.replace('_', ' ')}</strong>
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Submitted on <span className="font-mono text-slate-300">{claim.submissionDate}</span> for service rendered on{' '}
              <span className="font-mono text-slate-300">{claim.serviceDate}</span> ({claim.location})
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <div className="text-right">
              <span className="text-[11px] text-slate-400 block">Billed Total</span>
              <span className="text-xl font-bold font-mono text-white tabular-nums">
                {formatMoney(claim.billedAmount)}
              </span>
            </div>
            <div className="h-8 w-px bg-slate-800 hidden sm:block" />
            <div className="text-right">
              <span className="text-[11px] text-rose-400 block">Financial Exposure at Risk</span>
              <span className="text-xl font-bold font-mono text-rose-400 tabular-nums">
                {formatMoney(result.financialExposure)}
              </span>
            </div>
          </div>
        </div>

        {/* 4 Layer Score Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-5">
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80">
            <div className="flex justify-between items-center text-xs mb-1">
              <span className="text-slate-400 font-medium">ML Anomaly (35%)</span>
              <span className="font-mono font-semibold text-rose-400">{result.layers.anomalyScore}</span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
              <div
                className="bg-rose-500 h-full rounded-full transition-all"
                style={{ width: `${result.layers.anomalyScore}%` }}
              />
            </div>
            <span className="text-[10px] text-slate-500 mt-1 block">Statistical & cost outlier</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80">
            <div className="flex justify-between items-center text-xs mb-1">
              <span className="text-slate-400 font-medium">Duplicate (25%)</span>
              <span className="font-mono font-semibold text-amber-400">{result.layers.duplicateScore}</span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
              <div
                className="bg-amber-500 h-full rounded-full transition-all"
                style={{ width: `${result.layers.duplicateScore}%` }}
              />
            </div>
            <span className="text-[10px] text-slate-500 mt-1 block">Fuzzy & near-date collision</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80">
            <div className="flex justify-between items-center text-xs mb-1">
              <span className="text-slate-400 font-medium">Coding Error (20%)</span>
              <span className="font-mono font-semibold text-indigo-400">{result.layers.codingErrorScore}</span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
              <div
                className="bg-indigo-500 h-full rounded-full transition-all"
                style={{ width: `${result.layers.codingErrorScore}%` }}
              />
            </div>
            <span className="text-[10px] text-slate-500 mt-1 block">ICD-CPT & CCI unbundling</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80">
            <div className="flex justify-between items-center text-xs mb-1">
              <span className="text-slate-400 font-medium">Provider Risk (20%)</span>
              <span className="font-mono font-semibold text-purple-400">{result.layers.providerRiskScore}</span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
              <div
                className="bg-purple-500 h-full rounded-full transition-all"
                style={{ width: `${result.layers.providerRiskScore}%` }}
              />
            </div>
            <span className="text-[10px] text-slate-500 mt-1 block">Peer group & volume spike</span>
          </div>
        </div>
      </div>

      {/* Claim Metadata Quick Bar */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
        <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/60 flex items-start gap-3">
          <User className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
          <div>
            <span className="text-slate-400 block font-medium">Patient Details</span>
            <div className="text-slate-200 font-semibold mt-0.5">{claim.patientName}</div>
            <div className="text-slate-400 font-mono mt-0.5">
              ID: {claim.patientId} · {claim.patientAge} years · {claim.patientGender}
            </div>
          </div>
        </div>

        <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/60 flex items-start gap-3">
          <Building2 className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
          <div>
            <span className="text-slate-400 block font-medium">Billing Facility / Provider</span>
            <div className="text-slate-200 font-semibold mt-0.5">{claim.providerName}</div>
            <div className="text-slate-400 font-mono mt-0.5">
              NPI/ID: {claim.providerId} · {claim.providerSpecialty}
            </div>
          </div>
        </div>

        <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/60 flex items-start gap-3">
          <Stethoscope className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
          <div>
            <span className="text-slate-400 block font-medium">Procedure & Prior Auth</span>
            <div className="text-slate-200 font-semibold mt-0.5">CPT {claim.procedureCode} ({claim.units} unit)</div>
            <div className="text-slate-400 font-mono mt-0.5">
              Prior Auth: {claim.priorAuthorization ? 'Verified Yes' : 'None Documented'}
            </div>
          </div>
        </div>
      </div>

      {/* Duplicate Collision Quick Banner (if duplicate found) */}
      {result.duplicateMatch && (
        <div className="p-4 rounded-xl border border-rose-900/60 bg-rose-950/30 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0">
              <ArrowRightLeft className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-rose-200">
                  {result.duplicateMatch.similarity}% Collision with Pre-Existing Claim #{result.duplicateMatch.matchedClaimId}
                </span>
                <span className="text-[10px] font-mono uppercase bg-rose-900/60 px-1.5 py-0.2 rounded text-rose-300">
                  {result.duplicateMatch.matchType.replace('_', ' ')}
                </span>
              </div>
              <p className="text-xs text-rose-300/80 mt-0.5">
                Billed {result.duplicateMatch.dayDifference === 0 ? 'on same treatment date' : `${result.duplicateMatch.dayDifference} days apart`}. Potential double billing.
              </p>
            </div>
          </div>
          <button
            onClick={onOpenDuplicateDiff}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 shadow transition-colors shrink-0 whitespace-nowrap"
          >
            Open Side-by-Side Diff
          </button>
        </div>
      )}

      {/* Section Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 text-xs">
        <button
          onClick={() => setActiveTab('xai')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            activeTab === 'xai'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Explainable AI (SHAP & Narrative)
        </button>
        <button
          onClick={() => setActiveTab('clinical')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            activeTab === 'clinical'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Clinical Knowledge Graph
        </button>
        <button
          onClick={() => setActiveTab('peer')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            activeTab === 'peer'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Provider & Peer Benchmark
        </button>
        <button
          onClick={() => setActiveTab('audit')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            activeTab === 'audit'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Audit History & Feedback
        </button>
      </div>

      {/* Tab 1: Explainable AI Layer */}
      {activeTab === 'xai' && (
        <div className="space-y-6">
          {/* Natural Language Executive Dossier */}
          <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/60 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-semibold text-white flex items-center gap-2">
                <FileCheck2 className="w-4 h-4 text-indigo-400" />
                <span>Executive Investigator Dossier (Natural Language Explanation)</span>
              </h4>
              <button
                onClick={handleGenerateAiMemo}
                disabled={isGeneratingAiMemo}
                className="flex items-center gap-1.5 text-xs text-indigo-300 hover:text-white bg-indigo-950/60 border border-indigo-800/80 px-2.5 py-1 rounded transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                <span>{isGeneratingAiMemo ? 'Synthesizing...' : 'Generate Forensic Audit Memo'}</span>
              </button>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-950/80 border border-slate-800 text-xs space-y-2">
              <div className="font-semibold text-slate-200 text-sm">
                {result.naturalLanguageSummary.headline}
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                <div>
                  <span className="text-slate-400 font-medium block">Primary Driver:</span>
                  <p className="text-slate-300 mt-0.5">{result.naturalLanguageSummary.primaryDriver}</p>
                </div>
                <div>
                  <span className="text-slate-400 font-medium block">Secondary Driver:</span>
                  <p className="text-slate-300 mt-0.5">{result.naturalLanguageSummary.secondaryDriver}</p>
                </div>
              </div>
              <div className="pt-2 border-t border-slate-800/60">
                <span className="text-slate-400 font-medium block">Provider Context:</span>
                <p className="text-slate-300 mt-0.5">{result.naturalLanguageSummary.providerContext}</p>
              </div>
              <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400">
                <span>Regulatory / Policy Citation: <strong className="text-slate-300">{result.naturalLanguageSummary.regulatoryCitation}</strong></span>
                <span className="text-indigo-400 font-medium">{result.naturalLanguageSummary.recommendedAction}</span>
              </div>
            </div>

            {aiMemo && (
              <div className="p-4 rounded-xl border border-indigo-900/60 bg-indigo-950/30 text-xs font-mono text-indigo-200 whitespace-pre-line">
                {aiMemo}
              </div>
            )}
          </div>

          {/* Interactive SHAP Waterfall Chart */}
          <ShapWaterfallChart
            attributions={result.shapAttribution}
            compositeRiskScore={result.compositeRiskScore}
            baseBaseline={result.limeExplanation.intercept}
          />

          {/* LIME Local Counterfactual Statement */}
          <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/50 text-xs space-y-2">
            <div className="flex items-center gap-2 text-slate-300 font-semibold">
              <Scale className="w-4 h-4 text-amber-400" />
              <span>LIME Counterfactual Simulation (What would change the verdict?)</span>
            </div>
            <p className="text-slate-400">{result.limeExplanation.counterfactual}</p>
          </div>
        </div>
      )}

      {/* Tab 2: Clinical Knowledge Graph */}
      {activeTab === 'clinical' && (
        <div className="space-y-6">
          <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/60 space-y-4">
            <h4 className="text-sm font-semibold text-white flex items-center gap-2">
              <Stethoscope className="w-4 h-4 text-indigo-400" />
              <span>Diagnosis ↔ Procedure Clinical Compatibility Matrix</span>
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="p-3.5 rounded-lg bg-slate-950/80 border border-slate-800">
                <span className="text-slate-400 font-medium block">Documented Diagnosis (ICD-10)</span>
                <div className="text-base font-bold font-mono text-indigo-400 mt-1">
                  {claim.diagnosisCode}
                </div>
                <div className="text-slate-200 mt-0.5">{claim.diagnosisDesc}</div>
              </div>

              <div className="p-3.5 rounded-lg bg-slate-950/80 border border-slate-800">
                <span className="text-slate-400 font-medium block">Billed Procedure (CPT / HCPCS)</span>
                <div className="text-base font-bold font-mono text-slate-200 mt-1">
                  {claim.procedureCode}
                </div>
                <div className="text-slate-200 mt-0.5">{claim.procedureDesc}</div>
              </div>
            </div>

            <div className={`p-4 rounded-xl border ${
              result.clinicalCheck.isConsistent
                ? 'border-emerald-900/60 bg-emerald-950/30 text-emerald-300'
                : 'border-rose-900/60 bg-rose-950/30 text-rose-300'
            } text-xs space-y-2`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-semibold text-sm">
                  {result.clinicalCheck.isConsistent ? (
                    <CheckCircle className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-rose-400" />
                  )}
                  <span>
                    Clinical Compatibility Score: {result.clinicalCheck.compatibilityScore}% (
                    {result.clinicalCheck.isConsistent ? 'Consistent & Justified' : 'Severe Mismatch / Contradiction'}
                    )
                  </span>
                </div>
              </div>
              <p className="text-slate-300">{result.clinicalCheck.clinicalRationale}</p>
              <div className="text-[11px] text-slate-400 pt-1 border-t border-slate-800/60">
                Clinical Guideline Citation: <strong>{result.clinicalCheck.guidelineRef}</strong>
              </div>
            </div>

            {result.clinicalCheck.cciEditFound && (
              <div className="p-3.5 rounded-lg border border-amber-900/60 bg-amber-950/30 text-xs text-amber-300">
                <div className="font-semibold text-amber-200">CCI Unbundling / Upcoding Edit Flagged</div>
                <p className="mt-0.5">{result.clinicalCheck.cciDetail}</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 3: Provider & Peer Benchmark */}
      {activeTab === 'peer' && (
        <div className="space-y-6">
          <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/60 space-y-4">
            <h4 className="text-sm font-semibold text-white flex items-center gap-2">
              <Building2 className="w-4 h-4 text-indigo-400" />
              <span>Specialty Peer Group Benchmark & Behavioral Outlier Analysis</span>
            </h4>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
              <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800">
                <span className="text-slate-400 block">Peer Mean Cost</span>
                <span className="text-base font-bold font-mono text-white mt-1 block">
                  {formatMoney(result.peerBenchmark.peerMeanAmount)}
                </span>
                <span className="text-[11px] text-slate-500">±{formatMoney(result.peerBenchmark.peerStdDev)} (1σ)</span>
              </div>

              <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800">
                <span className="text-slate-400 block">Z-Score Deviation</span>
                <span className={`text-base font-bold font-mono mt-1 block ${
                  result.peerBenchmark.zScore > 2.5 ? 'text-rose-400' : 'text-emerald-400'
                }`}>
                  {result.peerBenchmark.zScore > 0 ? '+' : ''}{result.peerBenchmark.zScore}σ
                </span>
                <span className="text-[11px] text-slate-500">{result.peerBenchmark.percentile}th percentile</span>
              </div>

              <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800">
                <span className="text-slate-400 block">Monthly Procedure Volume</span>
                <span className="text-base font-bold font-mono text-white mt-1 block">
                  {result.peerBenchmark.providerMonthlyVolume} scans
                </span>
                <span className="text-[11px] text-slate-500">Peer avg: {result.peerBenchmark.specialtyAvgMonthlyVolume}</span>
              </div>

              <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800">
                <span className="text-slate-400 block">Historical Denial Rate</span>
                <span className="text-base font-bold font-mono text-amber-400 mt-1 block">
                  {result.peerBenchmark.providerDenialRate}%
                </span>
                <span className="text-[11px] text-slate-500">Peer avg: {result.peerBenchmark.peerDenialRate}%</span>
              </div>
            </div>

            {/* Visual Bell-Curve Dispersion */}
            <div className="p-4 rounded-xl bg-slate-950/90 border border-slate-800 space-y-2 text-xs">
              <span className="text-slate-400 font-medium block">Peer Cost Distribution Curve</span>
              <div className="relative pt-6 pb-2">
                {/* Horizontal scale */}
                <div className="h-2 bg-slate-800 rounded-full w-full relative">
                  {/* Normal band */}
                  <div className="absolute left-[20%] right-[35%] h-full bg-emerald-600/30 rounded" />
                  {/* Current claim marker */}
                  <div
                    className="absolute top-[-10px] w-4 h-4 bg-rose-500 rounded-full border-2 border-white shadow -ml-2"
                    style={{
                      left: `${Math.min(96, Math.max(8, 50 + result.peerBenchmark.zScore * 12))}%`,
                    }}
                    title={`Claim Amount: ${formatMoney(claim.billedAmount)}`}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-3">
                  <span>-2σ ({formatMoney(Math.max(0, result.peerBenchmark.peerMeanAmount - 2 * result.peerBenchmark.peerStdDev))})</span>
                  <span>Mean ({formatMoney(result.peerBenchmark.peerMeanAmount)})</span>
                  <span>+2σ ({formatMoney(result.peerBenchmark.peerMeanAmount + 2 * result.peerBenchmark.peerStdDev)})</span>
                  <span>+4σ Outlier</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Audit History & Feedback */}
      {activeTab === 'audit' && (
        <div className="space-y-6">
          <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/60 space-y-4">
            <h4 className="text-sm font-semibold text-white flex items-center gap-2">
              <ClipboardList className="w-4 h-4 text-indigo-400" />
              <span>Adjudication Audit Trail & Model Calibration Loop</span>
            </h4>

            <div className="space-y-3">
              {claim.historyLog.map((log) => (
                <div key={log.id} className="p-3 rounded-lg bg-slate-950/80 border border-slate-800 text-xs flex items-start gap-3">
                  <Clock className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-slate-200">{log.action}</span>
                      <span className="text-[11px] font-mono text-slate-400">· {log.timestamp}</span>
                      <span className="text-[11px] text-indigo-400">by {log.actor}</span>
                    </div>
                    <p className="text-slate-400">{log.note}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-3.5 rounded-lg border border-indigo-900/60 bg-indigo-950/30 text-xs text-indigo-300 flex items-start gap-2.5">
              <Info className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-indigo-200">Continuous Human-in-the-Loop Feedback:</span>
                <p className="mt-0.5 text-indigo-300/90">
                  When manual investigators confirm fraud or dismiss false positives, decisions feed back into our Bayesian calibration matrices to tune Isolation Forest tree thresholds and provider weighting.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Investigator Adjudication Action Panel */}
      <div className="p-5 rounded-2xl border border-slate-800 bg-slate-900/90 shadow-xl space-y-4">
        <h4 className="text-sm font-semibold text-white flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-rose-400" />
          <span>Investigator Adjudication Action Panel</span>
        </h4>

        <div className="space-y-2">
          <label className="text-xs text-slate-400 block font-medium">
            Investigator Case Note & Rationale
          </label>
          <textarea
            value={investigatorNote}
            onChange={(e) => setInvestigatorNote(e.target.value)}
            placeholder="Document rationale, clinical justification or specific policy reference for this decision..."
            rows={2}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2.5 pt-2">
          <button
            onClick={() => handleAction('confirmed_fraud', 'Confirmed Fraud / Upcoding')}
            className="px-3.5 py-2 rounded-lg text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 active:bg-rose-700 shadow-sm transition-colors"
          >
            Confirm Fraud / Upcoding
          </button>

          {result.duplicateMatch && (
            <button
              onClick={() => handleAction('confirmed_fraud', 'Confirmed Duplicate Billing')}
              className="px-3.5 py-2 rounded-lg text-xs font-semibold text-white bg-amber-600 hover:bg-amber-500 active:bg-amber-700 shadow-sm transition-colors"
            >
              Confirm Duplicate & Reject
            </button>
          )}

          <button
            onClick={() => handleAction('rfi_requested', 'Request Medical Records (RFI)')}
            className="px-3.5 py-2 rounded-lg text-xs font-medium border border-slate-700 text-slate-200 hover:text-white hover:bg-slate-800 transition-colors"
          >
            Request Records (RFI)
          </button>

          <button
            onClick={() => handleAction('siu_escalated', 'Escalate to SIU (Special Investigation Unit)')}
            className="px-3.5 py-2 rounded-lg text-xs font-medium border border-purple-800/80 bg-purple-950/40 text-purple-200 hover:text-white hover:bg-purple-900/60 transition-colors"
          >
            Escalate to SIU
          </button>

          <button
            onClick={() => handleAction('dismissed_clean', 'Dismiss Flag (Valid Medical Necessity)')}
            className="px-3.5 py-2 rounded-lg text-xs font-medium border border-slate-700 text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors ml-auto"
          >
            Dismiss (False Positive)
          </button>
        </div>
      </div>
    </div>
  );
};
