import React from 'react';
import { PolicyRule } from '../types';
import { ShieldCheck, ToggleLeft, ToggleRight, BookOpen, AlertCircle } from 'lucide-react';

interface PolicyRulesProps {
  rules: PolicyRule[];
  onToggleRule: (ruleId: string) => void;
}

export const PolicyRules: React.FC<PolicyRulesProps> = ({ rules, onToggleRule }) => {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-6 rounded-2xl border border-slate-800 bg-slate-900/80">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-indigo-400" />
          <span>Active Adjudication Policy Rules & Deterministic Edits</span>
        </h3>
        <p className="text-xs text-slate-400 mt-1 max-w-3xl">
          Deterministic and statistical checks anchored in CMS, IRDAI, and NCCI coding guidelines. Toggle individual rules to simulate how policy tuning affects scoring across the claims queue in real time.
        </p>
      </div>

      {/* Rules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {rules.map((rule) => {
          const categoryColors: Record<string, string> = {
            duplicate: 'text-amber-400 bg-amber-950/80 border-amber-800',
            coding_error: 'text-indigo-400 bg-indigo-950/80 border-indigo-800',
            ml_anomaly: 'text-rose-400 bg-rose-950/80 border-rose-800',
            provider_behavior: 'text-purple-400 bg-purple-950/80 border-purple-800',
            utilization: 'text-blue-400 bg-blue-950/80 border-blue-800',
          };

          return (
            <div
              key={rule.id}
              className={`p-5 rounded-xl border transition-all ${
                rule.enabled
                  ? 'border-slate-800 bg-slate-900/70 shadow-sm'
                  : 'border-slate-850 bg-slate-950/40 opacity-60'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-slate-300">
                      {rule.id}
                    </span>
                    <span
                      className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded border ${
                        categoryColors[rule.category] || 'text-slate-400 bg-slate-800'
                      }`}
                    >
                      {rule.category.replace('_', ' ')}
                    </span>
                    <span className="text-[10px] font-semibold uppercase text-rose-400">
                      {rule.severity}
                    </span>
                  </div>
                  <h4 className="text-sm font-semibold text-white">{rule.name}</h4>
                </div>

                <button
                  onClick={() => onToggleRule(rule.id)}
                  title={rule.enabled ? 'Click to disable rule' : 'Click to enable rule'}
                  className="text-slate-400 hover:text-white transition-colors shrink-0 p-1"
                >
                  {rule.enabled ? (
                    <ToggleRight className="w-6 h-6 text-indigo-400" />
                  ) : (
                    <ToggleLeft className="w-6 h-6 text-slate-600" />
                  )}
                </button>
              </div>

              <p className="text-xs text-slate-300 mt-2.5">{rule.description}</p>

              <div className="mt-4 pt-3 border-t border-slate-800/80 space-y-1.5 text-xs">
                <div className="flex items-baseline gap-2">
                  <span className="text-slate-500 font-medium shrink-0">Trigger Threshold:</span>
                  <span className="font-mono text-slate-300">{rule.threshold}</span>
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-slate-500 font-medium shrink-0">Policy Citation:</span>
                  <span className="text-slate-400 italic text-[11px]">{rule.policyCitation}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
