import React, { useState } from 'react';
import { Claim } from '../types';
import { DIAGNOSES_DATABASE, PROCEDURES_DATABASE } from '../engine/knowledgeGraph';
import { Play, Sparkles, Upload, FileCode, CheckCircle2, RotateCcw } from 'lucide-react';

interface BatchSandboxProps {
  onIngestClaim: (newClaim: Claim) => void;
  currency: 'INR' | 'USD';
  exchangeRate: number;
}

export const BatchSandbox: React.FC<BatchSandboxProps> = ({
  onIngestClaim,
  currency,
  exchangeRate,
}) => {
  const [patientName, setPatientName] = useState('Anand Verma');
  const [patientId, setPatientId] = useState('P-9912');
  const [patientAge, setPatientAge] = useState<number>(54);
  const [patientGender, setPatientGender] = useState<'M' | 'F' | 'Other'>('M');

  const [providerId, setProviderId] = useState('HSP-101');
  const [providerName, setProviderName] = useState('Apex Multispecialty Hospital');
  const [providerSpecialty, setProviderSpecialty] = useState('Cardiology');
  const [location, setLocation] = useState('Bangalore');

  const [diagnosisCode, setDiagnosisCode] = useState('J00');
  const [procedureCode, setProcedureCode] = useState('33533');
  const [billedAmount, setBilledAmount] = useState<number>(1800000);
  const [units, setUnits] = useState<number>(1);
  const [serviceDate, setServiceDate] = useState('2026-06-11');
  const [priorAuth, setPriorAuth] = useState(false);

  const [jsonInput, setJsonInput] = useState('');
  const [jsonError, setJsonError] = useState<string | null>(null);
  const [jsonSuccess, setJsonSuccess] = useState<string | null>(null);

  // Quick preset loader
  const loadPreset = (presetKey: string) => {
    if (presetKey === 'cold_bypass') {
      setDiagnosisCode('J00');
      setProcedureCode('33533');
      setBilledAmount(1800000);
      setProviderSpecialty('Cardiology');
      setProviderId('HSP-101');
      setProviderName('Apex Multispecialty Hospital');
      setPriorAuth(false);
      setPatientName('Anand Verma');
      setPatientAge(54);
      setPatientGender('M');
    } else if (presetKey === 'exact_duplicate') {
      setPatientId('P-001');
      setPatientName('Rajesh Kumar');
      setProviderId('HSP-101');
      setProviderName('Apex Multispecialty Hospital');
      setProviderSpecialty('Radiology');
      setDiagnosisCode('G43.909');
      setProcedureCode('70553');
      setBilledAmount(5000);
      setServiceDate('2026-06-10');
      setPriorAuth(true);
      setUnits(1);
    } else if (presetKey === 'provider_spike') {
      setProviderId('HSP-101');
      setProviderName('Apex Diagnostic & Imaging Hub');
      setProviderSpecialty('Radiology');
      setDiagnosisCode('R07.9');
      setProcedureCode('70553');
      setBilledAmount(8500);
      setUnits(1);
      setPriorAuth(false);
    } else if (presetKey === 'over_utilization') {
      setPatientId('P-2041');
      setPatientName('Ananya Deshmukh');
      setDiagnosisCode('G43.909');
      setProcedureCode('70553');
      setBilledAmount(64000);
      setUnits(8);
      setPriorAuth(false);
    } else if (presetKey === 'upcoding_lvl5') {
      setDiagnosisCode('M54.5');
      setProcedureCode('99291');
      setBilledAmount(24000);
      setProviderSpecialty('Critical Care');
      setUnits(1);
      setPriorAuth(false);
    } else if (presetKey === 'clean_cataract') {
      setDiagnosisCode('H25.9');
      setProcedureCode('66984');
      setBilledAmount(35000);
      setProviderSpecialty('Ophthalmology');
      setProviderName('Netra Eye Institute');
      setPatientName('Sushila Iyer');
      setPatientAge(67);
      setPatientGender('F');
      setUnits(1);
      setPriorAuth(true);
    }
  };

  const handleSimulate = () => {
    const diag = DIAGNOSES_DATABASE[diagnosisCode];
    const proc = PROCEDURES_DATABASE[procedureCode];
    const newId = `CLM-${Math.floor(10000 + Math.random() * 90000)}`;

    const newClaim: Claim = {
      id: newId,
      patientId,
      patientName,
      patientAge,
      patientGender,
      providerId,
      providerName,
      providerSpecialty,
      location,
      diagnosisCode,
      diagnosisDesc: diag ? diag.name : 'Documented Primary Diagnosis',
      procedureCode,
      procedureDesc: proc ? proc.name : 'Surgical / Diagnostic Procedure',
      units,
      billedAmount,
      serviceDate,
      submissionDate: new Date().toISOString().split('T')[0],
      priorAuthorization: priorAuth,
      status: 'pending_review',
      historyLog: [
        {
          id: `LOG-${Date.now()}`,
          action: 'Simulated Ingestion',
          timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
          note: 'Ingested via Investigator Simulation Sandbox.',
          actor: 'Investigator Sandbox',
        },
      ],
    };

    onIngestClaim(newClaim);
  };

  const handleBatchJsonSubmit = () => {
    setJsonError(null);
    setJsonSuccess(null);
    try {
      const parsed = JSON.parse(jsonInput);
      const items: Claim[] = Array.isArray(parsed) ? parsed : [parsed];

      let count = 0;
      items.forEach((item) => {
        if (!item.id) item.id = `CLM-${Math.floor(10000 + Math.random() * 90000)}`;
        if (!item.historyLog) {
          item.historyLog = [
            {
              id: `LOG-${Date.now()}-${count}`,
              action: 'Batch JSON Ingestion',
              timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
              note: 'Batch payload parsed into pipeline.',
              actor: 'Batch Pipeline',
            },
          ];
        }
        onIngestClaim(item);
        count++;
      });

      setJsonSuccess(`Successfully ingested ${count} claim(s) into active detection pipeline!`);
      setJsonInput('');
    } catch (e: any) {
      setJsonError(`Invalid JSON format: ${e.message}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Sandbox Header */}
      <div className="p-6 rounded-2xl border border-slate-800 bg-slate-900/80">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-indigo-400" />
          <span>Interactive Claim Ingestion & Simulation Sandbox</span>
        </h3>
        <p className="text-xs text-slate-400 mt-1 max-w-3xl">
          Test real-time anomaly detection, duplicate collision matching, clinical knowledge graph crosswalks, and SHAP explainability. Select from pre-configured fraud & anomaly test cases or build a custom claim.
        </p>

        {/* Preset scenario selectors */}
        <div className="mt-4 pt-4 border-t border-slate-800 flex flex-wrap items-center gap-2">
          <span className="text-xs font-semibold text-slate-300 mr-1">Load Presets:</span>
          <button
            onClick={() => loadPreset('cold_bypass')}
            className="px-2.5 py-1 text-xs rounded-lg bg-rose-950/80 text-rose-300 border border-rose-800 hover:bg-rose-900/60 transition-colors"
          >
            Heart Bypass for Cold (₹18L Mismatch)
          </button>
          <button
            onClick={() => loadPreset('exact_duplicate')}
            className="px-2.5 py-1 text-xs rounded-lg bg-amber-950/80 text-amber-300 border border-amber-800 hover:bg-amber-900/60 transition-colors"
          >
            Exact Duplicate Brain MRI (100% Collision)
          </button>
          <button
            onClick={() => loadPreset('provider_spike')}
            className="px-2.5 py-1 text-xs rounded-lg bg-purple-950/80 text-purple-300 border border-purple-800 hover:bg-purple-900/60 transition-colors"
          >
            Dr. Sharma 140 MRI Month (Provider Spike)
          </button>
          <button
            onClick={() => loadPreset('over_utilization')}
            className="px-2.5 py-1 text-xs rounded-lg bg-rose-950/80 text-rose-300 border border-rose-800 hover:bg-rose-900/60 transition-colors"
          >
            8 Scans in 60 Days (Excessive Utilization)
          </button>
          <button
            onClick={() => loadPreset('upcoding_lvl5')}
            className="px-2.5 py-1 text-xs rounded-lg bg-amber-950/80 text-amber-300 border border-amber-800 hover:bg-amber-900/60 transition-colors"
          >
            Critical Care for Back Pain (Level 5 Upcoding)
          </button>
          <button
            onClick={() => loadPreset('clean_cataract')}
            className="px-2.5 py-1 text-xs rounded-lg bg-emerald-950/80 text-emerald-300 border border-emerald-800 hover:bg-emerald-900/60 transition-colors"
          >
            Clean Cataract Surgery (Auto-Approve Baseline)
          </button>
        </div>
      </div>

      {/* Two Column Grid: Form Builder vs JSON Ingestion */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Form Builder (2 cols) */}
        <div className="lg:col-span-2 p-6 rounded-2xl border border-slate-800 bg-slate-900/60 space-y-5">
          <h4 className="text-sm font-semibold text-white">Custom Claim Builder</h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            {/* Patient Fields */}
            <div>
              <label className="text-slate-400 block mb-1">Patient Name</label>
              <input
                type="text"
                value={patientName}
                onChange={(e) => setPatientName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="text-slate-400 block mb-1">Patient ID</label>
              <input
                type="text"
                value={patientId}
                onChange={(e) => setPatientId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none focus:border-indigo-500 font-mono"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Age & Gender</label>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="number"
                  value={patientAge}
                  onChange={(e) => setPatientAge(Number(e.target.value))}
                  className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none focus:border-indigo-500 font-mono"
                />
                <select
                  value={patientGender}
                  onChange={(e) => setPatientGender(e.target.value as any)}
                  className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="M">Male (M)</option>
                  <option value="F">Female (F)</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Provider ID & Name</label>
              <div className="grid grid-cols-3 gap-2">
                <input
                  type="text"
                  value={providerId}
                  onChange={(e) => setProviderId(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none focus:border-indigo-500 font-mono"
                />
                <input
                  type="text"
                  value={providerName}
                  onChange={(e) => setProviderName(e.target.value)}
                  className="col-span-2 bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Provider Specialty</label>
              <select
                value={providerSpecialty}
                onChange={(e) => setProviderSpecialty(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="Cardiology">Cardiology</option>
                <option value="Radiology">Radiology</option>
                <option value="Orthopedics">Orthopedics</option>
                <option value="General Medicine">General Medicine</option>
                <option value="Ophthalmology">Ophthalmology</option>
                <option value="Oncology">Oncology</option>
                <option value="Critical Care">Critical Care</option>
                <option value="Physical Medicine">Physical Medicine</option>
              </select>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Service Location</label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            {/* Diagnosis (ICD-10) */}
            <div className="sm:col-span-2">
              <label className="text-slate-400 block mb-1">Primary Diagnosis (ICD-10 Code)</label>
              <select
                value={diagnosisCode}
                onChange={(e) => setDiagnosisCode(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none focus:border-indigo-500 font-mono"
              >
                {Object.values(DIAGNOSES_DATABASE).map((d) => (
                  <option key={d.code} value={d.code}>
                    {d.code} - {d.name} ({d.category})
                  </option>
                ))}
              </select>
            </div>

            {/* Procedure (CPT) */}
            <div className="sm:col-span-2">
              <label className="text-slate-400 block mb-1">Billed Procedure (CPT Code)</label>
              <select
                value={procedureCode}
                onChange={(e) => setProcedureCode(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none focus:border-indigo-500 font-mono"
              >
                {Object.values(PROCEDURES_DATABASE).map((p) => (
                  <option key={p.code} value={p.code}>
                    {p.code} - {p.name} [Peer avg: ₹{p.peerMeanAmount.toLocaleString('en-IN')}]
                  </option>
                ))}
              </select>
            </div>

            {/* Billed Amount & Units */}
            <div>
              <label className="text-slate-400 block mb-1">Billed Amount (INR ₹)</label>
              <input
                type="number"
                value={billedAmount}
                onChange={(e) => setBilledAmount(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none focus:border-indigo-500 font-mono tabular-nums text-sm font-semibold"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Treatment Service Date</label>
              <input
                type="date"
                value={serviceDate}
                onChange={(e) => setServiceDate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none focus:border-indigo-500 font-mono"
              />
            </div>

            <div className="flex items-center gap-2 pt-2">
              <input
                type="checkbox"
                id="priorAuthCheck"
                checked={priorAuth}
                onChange={(e) => setPriorAuth(e.target.checked)}
                className="rounded border-slate-700 text-indigo-600 focus:ring-0"
              />
              <label htmlFor="priorAuthCheck" className="text-slate-300 select-none cursor-pointer">
                Prior Authorization Verified on File
              </label>
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              onClick={handleSimulate}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 shadow-lg shadow-indigo-600/20 transition-all"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Run Detection Engine & Ingest Claim</span>
            </button>
          </div>
        </div>

        {/* Batch JSON Ingestion (1 col) */}
        <div className="p-6 rounded-2xl border border-slate-800 bg-slate-900/60 flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-white flex items-center gap-2">
              <FileCode className="w-4 h-4 text-slate-400" />
              <span>Batch JSON Payload</span>
            </h4>
            <p className="text-xs text-slate-400">
              Paste raw JSON claims array from external EHR / Payer EDI 837 data feed to ingest multiple records simultaneously.
            </p>

            <textarea
              value={jsonInput}
              onChange={(e) => setJsonInput(e.target.value)}
              placeholder='[ { "patientId": "P-99", "procedureCode": "33533", "billedAmount": 1800000, ... } ]'
              rows={9}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-white font-mono focus:outline-none focus:border-indigo-500"
            />

            {jsonError && (
              <div className="p-2 rounded bg-rose-950/60 border border-rose-800 text-[11px] text-rose-300">
                {jsonError}
              </div>
            )}
            {jsonSuccess && (
              <div className="p-2 rounded bg-emerald-950/60 border border-emerald-800 text-[11px] text-emerald-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{jsonSuccess}</span>
              </div>
            )}
          </div>

          <button
            onClick={handleBatchJsonSubmit}
            disabled={!jsonInput.trim()}
            className="w-full flex items-center justify-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 disabled:opacity-40 transition-colors"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Ingest JSON Batch</span>
          </button>
        </div>
      </div>
    </div>
  );
};
