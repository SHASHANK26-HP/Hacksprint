import React from 'react';
import { Claim, DetectionResult } from '../types';
import {
  TrendingUp,
  Clock,
  CopyCheck,
  ShieldCheck,
  Award,
  BarChart3,
  PieChart,
  DollarSign,
  Activity,
  Layers,
} from 'lucide-react';

interface ModelAnalyticsProps {
  claims: Claim[];
  detectionResults: Map<string, DetectionResult>;
  currency: 'INR' | 'USD';
  exchangeRate: number;
}

export const ModelAnalytics: React.FC<ModelAnalyticsProps> = ({
  claims,
  detectionResults,
  currency,
  exchangeRate,
}) => {
  const formatMoney = (inrVal: number) => {
    if (currency === 'USD') {
      const usdVal = Math.round(inrVal / exchangeRate);
      return `$${usdVal.toLocaleString('en-US')}`;
    }
    return `₹${inrVal.toLocaleString('en-IN')}`;
  };

  // Calculate statistics
  let totalBilled = 0;
  let totalExposure = 0;
  let highRiskCount = 0;
  let monitorCount = 0;
  let autoApproveCount = 0;

  const flagCounts: Record<string, number> = {
    duplicate: 0,
    coding_error: 0,
    ml_anomaly: 0,
    provider_behavior: 0,
    utilization: 0,
  };

  claims.forEach((c) => {
    totalBilled += c.billedAmount;
    const res = detectionResults.get(c.id);
    if (res) {
      totalExposure += res.financialExposure;
      if (res.riskTier === 'investigate') highRiskCount++;
      else if (res.riskTier === 'monitor') monitorCount++;
      else autoApproveCount++;

      res.flags.forEach((f) => {
        flagCounts[f.module] = (flagCounts[f.module] || 0) + 1;
      });
    }
  });

  const totalFlags = Object.values(flagCounts).reduce((a, b) => a + b, 0) || 1;

  return (
    <div className="space-y-6">
      {/* Top Value Cards: Expected Benefits as specified in brief */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <div className="p-4 rounded-xl border border-indigo-900/60 bg-indigo-950/20">
          <div className="flex items-center justify-between text-indigo-400">
            <span className="text-xs font-semibold">Fraud Detection</span>
            <TrendingUp className="w-4 h-4" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono text-white tabular-nums">
            +40%
          </div>
          <span className="text-[11px] text-slate-400">vs Legacy Rule-Only</span>
        </div>

        <div className="p-4 rounded-xl border border-emerald-900/60 bg-emerald-950/20">
          <div className="flex items-center justify-between text-emerald-400">
            <span className="text-xs font-semibold">Manual Effort</span>
            <Clock className="w-4 h-4" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono text-emerald-400 tabular-nums">
            -60%
          </div>
          <span className="text-[11px] text-slate-400">Auditor Hours Saved</span>
        </div>

        <div className="p-4 rounded-xl border border-amber-900/60 bg-amber-950/20">
          <div className="flex items-center justify-between text-amber-400">
            <span className="text-xs font-semibold">Duplicate Elimination</span>
            <CopyCheck className="w-4 h-4" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono text-amber-400 tabular-nums">
            -80%
          </div>
          <span className="text-[11px] text-slate-400">Fuzzy Collision Catch</span>
        </div>

        <div className="p-4 rounded-xl border border-blue-900/60 bg-blue-950/20">
          <div className="flex items-center justify-between text-blue-400">
            <span className="text-xs font-semibold">Cycle Turnaround</span>
            <Activity className="w-4 h-4" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono text-blue-400 tabular-nums">
            -70%
          </div>
          <span className="text-[11px] text-slate-400">Adjudication Latency</span>
        </div>

        <div className="p-4 rounded-xl border border-purple-900/60 bg-purple-950/20">
          <div className="flex items-center justify-between text-purple-400">
            <span className="text-xs font-semibold">Explainability</span>
            <Award className="w-4 h-4" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono text-purple-400 tabular-nums">
            100%
          </div>
          <span className="text-[11px] text-slate-400">SHAP & Citation Trail</span>
        </div>
      </div>

      {/* Financial Exposure & Recovery Summary */}
      <div className="p-6 rounded-2xl border border-slate-800 bg-slate-900/80">
        <h4 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
          <DollarSign className="w-4 h-4 text-emerald-400" />
          <span>Actuarial Financial Impact & Leakage Prevention</span>
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-1">
            <span className="text-xs text-slate-400">Gross Billed Value Evaluated</span>
            <div className="text-2xl font-bold font-mono text-white tabular-nums">
              {formatMoney(totalBilled)}
            </div>
            <p className="text-[11px] text-slate-500">Across {claims.length} total processed claim files</p>
          </div>

          <div className="space-y-1">
            <span className="text-xs text-rose-400">Identified High-Risk Exposure</span>
            <div className="text-2xl font-bold font-mono text-rose-400 tabular-nums">
              {formatMoney(totalExposure)}
            </div>
            <p className="text-[11px] text-slate-500">
              {Math.round((totalExposure / (totalBilled || 1)) * 100)}% of total claim expenditure flagged for audit
            </p>
          </div>

          <div className="space-y-1">
            <span className="text-xs text-emerald-400">Estimated Prevented Financial Leakage</span>
            <div className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">
              {formatMoney(Math.round(totalExposure * 0.88))}
            </div>
            <p className="text-[11px] text-slate-500">Based on 88% historic SIU confirmation yield</p>
          </div>
        </div>
      </div>

      {/* Two Column Grid: Flag Module Distribution & Risk Tier Histogram */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Module Breakdown */}
        <div className="p-6 rounded-2xl border border-slate-800 bg-slate-900/60 space-y-4">
          <h4 className="text-sm font-semibold text-white flex items-center gap-2">
            <PieChart className="w-4 h-4 text-indigo-400" />
            <span>Detection Module Distribution</span>
          </h4>

          <div className="space-y-3 text-xs">
            {/* Duplicates */}
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span className="font-medium">Duplicate & Collision Detection</span>
                <span className="font-mono text-amber-400">
                  {flagCounts.duplicate} flags ({Math.round((flagCounts.duplicate / totalFlags) * 100)}%)
                </span>
              </div>
              <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
                <div
                  className="bg-amber-500 h-full rounded-full"
                  style={{ width: `${(flagCounts.duplicate / totalFlags) * 100}%` }}
                />
              </div>
            </div>

            {/* Coding Errors */}
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span className="font-medium">Coding Inconsistencies & Upcoding</span>
                <span className="font-mono text-indigo-400">
                  {flagCounts.coding_error} flags ({Math.round((flagCounts.coding_error / totalFlags) * 100)}%)
                </span>
              </div>
              <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
                <div
                  className="bg-indigo-500 h-full rounded-full"
                  style={{ width: `${(flagCounts.coding_error / totalFlags) * 100}%` }}
                />
              </div>
            </div>

            {/* ML Anomalies */}
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span className="font-medium">ML Cost & Statistical Outliers</span>
                <span className="font-mono text-rose-400">
                  {flagCounts.ml_anomaly} flags ({Math.round((flagCounts.ml_anomaly / totalFlags) * 100)}%)
                </span>
              </div>
              <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
                <div
                  className="bg-rose-500 h-full rounded-full"
                  style={{ width: `${(flagCounts.ml_anomaly / totalFlags) * 100}%` }}
                />
              </div>
            </div>

            {/* Provider Spikes */}
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span className="font-medium">Provider Behavioral Spikes (DBSCAN)</span>
                <span className="font-mono text-purple-400">
                  {flagCounts.provider_behavior} flags ({Math.round((flagCounts.provider_behavior / totalFlags) * 100)}%)
                </span>
              </div>
              <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
                <div
                  className="bg-purple-500 h-full rounded-full"
                  style={{ width: `${(flagCounts.provider_behavior / totalFlags) * 100}%` }}
                />
              </div>
            </div>

            {/* Utilization */}
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span className="font-medium">Excessive Patient Utilization</span>
                <span className="font-mono text-blue-400">
                  {flagCounts.utilization} flags ({Math.round((flagCounts.utilization / totalFlags) * 100)}%)
                </span>
              </div>
              <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
                <div
                  className="bg-blue-500 h-full rounded-full"
                  style={{ width: `${(flagCounts.utilization / totalFlags) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Risk Tier Segmentation */}
        <div className="p-6 rounded-2xl border border-slate-800 bg-slate-900/60 space-y-4">
          <h4 className="text-sm font-semibold text-white flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-emerald-400" />
            <span>Risk Score Tier Segmentation</span>
          </h4>

          <div className="space-y-4 text-xs">
            <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
              <div>
                <span className="font-semibold text-rose-300 block">High Risk / Investigate (70-100)</span>
                <span className="text-[11px] text-slate-400">Action: Priority Manual Audit / SIU</span>
              </div>
              <div className="text-right">
                <span className="font-mono font-bold text-base text-rose-400 tabular-nums">
                  {highRiskCount}
                </span>
                <span className="text-[11px] text-slate-500 block">
                  {Math.round((highRiskCount / claims.length) * 100)}%
                </span>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
              <div>
                <span className="font-semibold text-amber-300 block">Medium Risk / Monitor (40-69)</span>
                <span className="text-[11px] text-slate-400">Action: 10% Post-Adjudication Sampling</span>
              </div>
              <div className="text-right">
                <span className="font-mono font-bold text-base text-amber-400 tabular-nums">
                  {monitorCount}
                </span>
                <span className="text-[11px] text-slate-500 block">
                  {Math.round((monitorCount / claims.length) * 100)}%
                </span>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
              <div>
                <span className="font-semibold text-emerald-300 block">Low Risk / Auto-Approve (0-39)</span>
                <span className="text-[11px] text-slate-400">Action: Automated Straight-Through Processing</span>
              </div>
              <div className="text-right">
                <span className="font-mono font-bold text-base text-emerald-400 tabular-nums">
                  {autoApproveCount}
                </span>
                <span className="text-[11px] text-slate-500 block">
                  {Math.round((autoApproveCount / claims.length) * 100)}%
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
