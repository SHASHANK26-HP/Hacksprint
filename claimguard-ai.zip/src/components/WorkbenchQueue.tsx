import React, { useState, useMemo } from 'react';
import { Claim, DetectionResult } from '../types';
import {
  Search,
  AlertOctagon,
  ArrowUpDown,
  FileText,
  CheckCircle,
  Copy,
  Activity,
  Layers,
  Hospital,
} from 'lucide-react';

interface WorkbenchQueueProps {
  claims: Claim[];
  detectionResults: Map<string, DetectionResult>;
  selectedClaimId: string | null;
  onSelectClaim: (claimId: string) => void;
  currency: 'INR' | 'USD';
  exchangeRate: number;
  onQuickApprove: (claimId: string) => void;
  onViewDuplicateDiff: (claimId: string) => void;
}

export const WorkbenchQueue: React.FC<WorkbenchQueueProps> = ({
  claims,
  detectionResults,
  selectedClaimId,
  onSelectClaim,
  currency,
  exchangeRate,
  onQuickApprove,
  onViewDuplicateDiff,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<
    'all' | 'high' | 'medium' | 'auto_approve' | 'duplicate' | 'coding' | 'anomaly' | 'provider'
  >('all');
  const [sortBy, setSortBy] = useState<'score' | 'amount' | 'exposure' | 'date'>('score');
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');

  const formatMoney = (inrVal: number) => {
    if (currency === 'USD') {
      const usdVal = Math.round(inrVal / exchangeRate);
      return `$${usdVal.toLocaleString('en-US')}`;
    }
    return `₹${inrVal.toLocaleString('en-IN')}`;
  };

  // Filter and sort claims
  const filteredClaims = useMemo(() => {
    return claims.filter((claim) => {
      const result = detectionResults.get(claim.id);
      if (!result) return true;

      // Filter category
      if (activeFilter === 'high' && result.riskTier !== 'investigate') return false;
      if (activeFilter === 'medium' && result.riskTier !== 'monitor') return false;
      if (activeFilter === 'auto_approve' && result.riskTier !== 'auto_approve') return false;
      if (activeFilter === 'duplicate' && !result.flags.some((f) => f.module === 'duplicate'))
        return false;
      if (activeFilter === 'coding' && !result.flags.some((f) => f.module === 'coding_error'))
        return false;
      if (activeFilter === 'anomaly' && !result.flags.some((f) => f.module === 'ml_anomaly'))
        return false;
      if (activeFilter === 'provider' && !result.flags.some((f) => f.module === 'provider_behavior'))
        return false;

      // Text query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesText =
          claim.id.toLowerCase().includes(q) ||
          claim.patientId.toLowerCase().includes(q) ||
          claim.patientName.toLowerCase().includes(q) ||
          claim.providerName.toLowerCase().includes(q) ||
          claim.diagnosisCode.toLowerCase().includes(q) ||
          claim.procedureCode.toLowerCase().includes(q) ||
          claim.location.toLowerCase().includes(q);
        if (!matchesText) return false;
      }

      return true;
    }).sort((a, b) => {
      const resA = detectionResults.get(a.id);
      const resB = detectionResults.get(b.id);
      const scoreA = resA ? resA.compositeRiskScore : 0;
      const scoreB = resB ? resB.compositeRiskScore : 0;
      const expA = resA ? resA.financialExposure : 0;
      const expB = resB ? resB.financialExposure : 0;

      let diff = 0;
      if (sortBy === 'score') diff = scoreB - scoreA;
      else if (sortBy === 'amount') diff = b.billedAmount - a.billedAmount;
      else if (sortBy === 'exposure') diff = expB - expA;
      else if (sortBy === 'date')
        diff = new Date(b.serviceDate).getTime() - new Date(a.serviceDate).getTime();

      return sortOrder === 'desc' ? diff : -diff;
    });
  }, [claims, detectionResults, activeFilter, searchQuery, sortBy, sortOrder]);

  // Aggregate stats
  const stats = useMemo(() => {
    let highRiskCount = 0;
    let totalExposure = 0;
    let autoApproveCount = 0;

    claims.forEach((c) => {
      const r = detectionResults.get(c.id);
      if (r) {
        if (r.riskTier === 'investigate') highRiskCount++;
        if (r.riskTier === 'auto_approve') autoApproveCount++;
        totalExposure += r.financialExposure;
      }
    });

    return {
      total: claims.length,
      highRiskCount,
      autoApproveCount,
      totalExposure,
    };
  }, [claims, detectionResults]);

  const toggleSort = (field: 'score' | 'amount' | 'exposure' | 'date') => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'desc' ? 'asc' : 'desc');
    } else {
      setSortBy(field);
      setSortOrder('desc');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Metric Strip (High-Density SaaS) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/70">
          <span className="text-xs font-medium text-slate-400 block">Total Claims Audited</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white tabular-nums">
              {stats.total}
            </span>
            <span className="text-xs text-slate-500">Active pipeline</span>
          </div>
        </div>

        <div className="p-4 rounded-xl border border-rose-900/40 bg-rose-950/20">
          <span className="text-xs font-medium text-rose-300 block">Investigate / High Risk (70-100)</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-rose-400 tabular-nums">
              {stats.highRiskCount}
            </span>
            <span className="text-xs text-rose-300/80">
              ({Math.round((stats.highRiskCount / stats.total) * 100)}% of claims)
            </span>
          </div>
        </div>

        <div className="p-4 rounded-xl border border-amber-900/40 bg-amber-950/20">
          <span className="text-xs font-medium text-amber-300 block">Total Financial Exposure at Risk</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-amber-400 tabular-nums">
              {formatMoney(stats.totalExposure)}
            </span>
            <span className="text-xs text-amber-300/80">Composite exposure</span>
          </div>
        </div>

        <div className="p-4 rounded-xl border border-emerald-900/40 bg-emerald-950/20">
          <span className="text-xs font-medium text-emerald-300 block">Auto-Approved (0-39)</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">
              {stats.autoApproveCount}
            </span>
            <span className="text-xs text-emerald-300/80">Zero manual touch</span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        {/* Filter buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 p-1 bg-slate-900 rounded-lg border border-slate-800 text-xs shrink-0">
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-3 py-1.5 rounded transition-colors whitespace-nowrap ${
              activeFilter === 'all'
                ? 'bg-slate-800 text-white font-medium shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            All ({claims.length})
          </button>
          <button
            onClick={() => setActiveFilter('high')}
            className={`px-3 py-1.5 rounded transition-colors whitespace-nowrap ${
              activeFilter === 'high'
                ? 'bg-rose-900/70 text-rose-200 font-medium border border-rose-700/60'
                : 'text-rose-400/80 hover:text-rose-300'
            }`}
          >
            High Risk ({stats.highRiskCount})
          </button>
          <button
            onClick={() => setActiveFilter('medium')}
            className={`px-3 py-1.5 rounded transition-colors whitespace-nowrap ${
              activeFilter === 'medium'
                ? 'bg-amber-900/70 text-amber-200 font-medium border border-amber-700/60'
                : 'text-amber-400/80 hover:text-amber-300'
            }`}
          >
            Monitor (40-69)
          </button>
          <button
            onClick={() => setActiveFilter('auto_approve')}
            className={`px-3 py-1.5 rounded transition-colors whitespace-nowrap ${
              activeFilter === 'auto_approve'
                ? 'bg-emerald-900/70 text-emerald-200 font-medium border border-emerald-700/60'
                : 'text-emerald-400/80 hover:text-emerald-300'
            }`}
          >
            Auto-Approve
          </button>
          <button
            onClick={() => setActiveFilter('duplicate')}
            className={`px-3 py-1.5 rounded transition-colors whitespace-nowrap ${
              activeFilter === 'duplicate'
                ? 'bg-slate-800 text-white font-medium shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Duplicates
          </button>
          <button
            onClick={() => setActiveFilter('coding')}
            className={`px-3 py-1.5 rounded transition-colors whitespace-nowrap ${
              activeFilter === 'coding'
                ? 'bg-slate-800 text-white font-medium shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Coding Errors
          </button>
          <button
            onClick={() => setActiveFilter('anomaly')}
            className={`px-3 py-1.5 rounded transition-colors whitespace-nowrap ${
              activeFilter === 'anomaly'
                ? 'bg-slate-800 text-white font-medium shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Cost Outliers
          </button>
          <button
            onClick={() => setActiveFilter('provider')}
            className={`px-3 py-1.5 rounded transition-colors whitespace-nowrap ${
              activeFilter === 'provider'
                ? 'bg-slate-800 text-white font-medium shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Provider Spikes
          </button>
        </div>

        {/* Search Input */}
        <div className="relative w-full lg:w-72">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search claim, patient, CPT, ICD..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
          />
        </div>
      </div>

      {/* Data Table */}
      <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-900/60 shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/80 text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
                <th className="py-3 px-4">
                  <button
                    onClick={() => toggleSort('date')}
                    className="flex items-center gap-1 hover:text-white transition-colors"
                  >
                    <span>Claim ID / Date</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-500" />
                  </button>
                </th>
                <th className="py-3 px-4">Patient Demographics</th>
                <th className="py-3 px-4">Provider & Facility</th>
                <th className="py-3 px-4">Diagnosis ↔ Procedure</th>
                <th className="py-3 px-4 text-right">
                  <button
                    onClick={() => toggleSort('amount')}
                    className="flex items-center gap-1 hover:text-white transition-colors ml-auto"
                  >
                    <span>Billed Amount</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-500" />
                  </button>
                </th>
                <th className="py-3 px-4">
                  <button
                    onClick={() => toggleSort('score')}
                    className="flex items-center gap-1 hover:text-white transition-colors"
                  >
                    <span>Risk Score</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-500" />
                  </button>
                </th>
                <th className="py-3 px-4">Key Detection Signal</th>
                <th className="py-3 px-4 text-right">Adjudication</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredClaims.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    <p className="text-sm font-medium">No claims match the active filters.</p>
                    <p className="text-xs text-slate-500 mt-1">
                      Try clearing the search query or selecting a different filter tab.
                    </p>
                  </td>
                </tr>
              ) : (
                filteredClaims.map((claim) => {
                  const result = detectionResults.get(claim.id);
                  const isSelected = claim.id === selectedClaimId;
                  const score = result ? result.compositeRiskScore : 0;
                  const tier = result ? result.riskTier : 'auto_approve';
                  const topFlag = result?.flags[0];

                  return (
                    <tr
                      key={claim.id}
                      onClick={() => onSelectClaim(claim.id)}
                      className={`cursor-pointer transition-colors ${
                        isSelected
                          ? 'bg-indigo-950/30 hover:bg-indigo-950/40'
                          : 'hover:bg-slate-800/40'
                      }`}
                    >
                      {/* Claim ID & Date */}
                      <td className="py-3 px-4">
                        <div className="font-mono font-semibold text-slate-200">
                          {claim.id}
                        </div>
                        <div className="text-[11px] text-slate-500 font-mono">
                          {claim.serviceDate}
                        </div>
                      </td>

                      {/* Patient */}
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-200">{claim.patientName}</div>
                        <div className="text-[11px] text-slate-400 font-mono">
                          {claim.patientId} · {claim.patientAge}y · {claim.patientGender}
                        </div>
                      </td>

                      {/* Provider */}
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-300 truncate max-w-[170px]" title={claim.providerName}>
                          {claim.providerName}
                        </div>
                        <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                          <span>{claim.providerSpecialty}</span>
                          <span>·</span>
                          <span>{claim.location}</span>
                        </div>
                      </td>

                      {/* Diagnosis & Procedure */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono font-semibold text-indigo-300">
                            {claim.diagnosisCode}
                          </span>
                          <span className="text-slate-500">↔</span>
                          <span className="font-mono font-semibold text-slate-200">
                            {claim.procedureCode}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400 truncate max-w-[210px]" title={claim.procedureDesc}>
                          {claim.procedureDesc}
                        </div>
                      </td>

                      {/* Billed Amount */}
                      <td className="py-3 px-4 text-right font-mono tabular-nums">
                        <div className="font-semibold text-slate-200">
                          {formatMoney(claim.billedAmount)}
                        </div>
                        {result && result.peerBenchmark.zScore > 1.0 && (
                          <div className="text-[11px] text-amber-400">
                            +{result.peerBenchmark.zScore}σ vs peer
                          </div>
                        )}
                      </td>

                      {/* Risk Score */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <div
                            className={`font-mono font-bold text-xs px-2 py-0.5 rounded border tabular-nums ${
                              score >= 70
                                ? 'bg-rose-950/70 text-rose-300 border-rose-800'
                                : score >= 40
                                ? 'bg-amber-950/70 text-amber-300 border-amber-800'
                                : 'bg-emerald-950/70 text-emerald-300 border-emerald-800'
                            }`}
                          >
                            {score}
                          </div>
                          <span className="text-[11px] text-slate-400 capitalize">
                            {tier.replace('_', ' ')}
                          </span>
                        </div>
                        {/* 4 Mini Layer indicators */}
                        {result && (
                          <div className="flex items-center gap-1 mt-1.5">
                            <span
                              title={`ML Anomaly: ${result.layers.anomalyScore}`}
                              className={`h-1 w-3.5 rounded-full ${
                                result.layers.anomalyScore > 60
                                  ? 'bg-rose-500'
                                  : result.layers.anomalyScore > 30
                                  ? 'bg-amber-500'
                                  : 'bg-slate-700'
                              }`}
                            />
                            <span
                              title={`Duplicate: ${result.layers.duplicateScore}`}
                              className={`h-1 w-3.5 rounded-full ${
                                result.layers.duplicateScore > 60
                                  ? 'bg-rose-500'
                                  : result.layers.duplicateScore > 30
                                  ? 'bg-amber-500'
                                  : 'bg-slate-700'
                              }`}
                            />
                            <span
                              title={`Coding Error: ${result.layers.codingErrorScore}`}
                              className={`h-1 w-3.5 rounded-full ${
                                result.layers.codingErrorScore > 60
                                  ? 'bg-rose-500'
                                  : result.layers.codingErrorScore > 30
                                  ? 'bg-amber-500'
                                  : 'bg-slate-700'
                              }`}
                            />
                            <span
                              title={`Provider Behavior: ${result.layers.providerRiskScore}`}
                              className={`h-1 w-3.5 rounded-full ${
                                result.layers.providerRiskScore > 60
                                  ? 'bg-rose-500'
                                  : result.layers.providerRiskScore > 30
                                  ? 'bg-amber-500'
                                  : 'bg-slate-700'
                              }`}
                            />
                          </div>
                        )}
                      </td>

                      {/* Primary Signal */}
                      <td className="py-3 px-4">
                        {topFlag ? (
                          <div className="truncate max-w-[240px]">
                            <span className="font-medium text-slate-300 block truncate">
                              {topFlag.title}
                            </span>
                            <span className="text-[11px] text-slate-500 truncate block">
                              {topFlag.description}
                            </span>
                          </div>
                        ) : (
                          <span className="text-slate-500 text-[11px]">
                            Clean actuarial baseline
                          </span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
                          {result?.duplicateMatch && (
                            <button
                              onClick={() => onViewDuplicateDiff(claim.id)}
                              title="Compare Duplicate Side-by-Side"
                              className="p-1.5 text-rose-400 hover:text-white hover:bg-rose-900/60 rounded border border-rose-800/80 transition-colors"
                            >
                              <Copy className="w-3.5 h-3.5" />
                            </button>
                          )}
                          <button
                            onClick={() => onSelectClaim(claim.id)}
                            title="Inspect Full Evidence Dossier"
                            className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded border border-slate-700 transition-colors"
                          >
                            <FileText className="w-3.5 h-3.5" />
                          </button>
                          {score < 40 && claim.status !== 'dismissed_clean' && (
                            <button
                              onClick={() => onQuickApprove(claim.id)}
                              title="Approve Clean Claim"
                              className="p-1.5 text-emerald-400 hover:text-white hover:bg-emerald-900/60 rounded border border-emerald-800/80 transition-colors"
                            >
                              <CheckCircle className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
