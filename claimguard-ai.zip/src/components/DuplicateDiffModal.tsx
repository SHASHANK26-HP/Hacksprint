import React from 'react';
import { Claim, DuplicateMatchDetail } from '../types';
import { CheckCircle2, AlertTriangle, XCircle, ArrowRightLeft } from 'lucide-react';

interface DuplicateDiffModalProps {
  currentClaim: Claim;
  match: DuplicateMatchDetail;
  currency: 'INR' | 'USD';
  exchangeRate: number;
  onConfirmDuplicate: () => void;
  onDismissDuplicate: () => void;
  onClose: () => void;
}

export const DuplicateDiffModal: React.FC<DuplicateDiffModalProps> = ({
  currentClaim,
  match,
  currency,
  exchangeRate,
  onConfirmDuplicate,
  onDismissDuplicate,
  onClose,
}) => {
  const original = match.matchedClaim;

  const formatMoney = (inrVal: number) => {
    if (currency === 'USD') {
      const usdVal = Math.round(inrVal / exchangeRate);
      return `$${usdVal.toLocaleString('en-US')}`;
    }
    return `₹${inrVal.toLocaleString('en-IN')}`;
  };

  const fields = [
    {
      label: 'Claim ID',
      curr: currentClaim.id,
      orig: original.id,
      isMatch: currentClaim.id === original.id,
    },
    {
      label: 'Patient ID',
      curr: `${currentClaim.patientId} (${currentClaim.patientName})`,
      orig: `${original.patientId} (${original.patientName})`,
      isMatch: currentClaim.patientId === original.patientId,
    },
    {
      label: 'Provider ID & Name',
      curr: `${currentClaim.providerId} · ${currentClaim.providerName}`,
      orig: `${original.providerId} · ${original.providerName}`,
      isMatch: currentClaim.providerId === original.providerId,
    },
    {
      label: 'Procedure (CPT)',
      curr: `${currentClaim.procedureCode} - ${currentClaim.procedureDesc}`,
      orig: `${original.procedureCode} - ${original.procedureDesc}`,
      isMatch: currentClaim.procedureCode === original.procedureCode,
    },
    {
      label: 'Diagnosis (ICD-10)',
      curr: `${currentClaim.diagnosisCode} - ${currentClaim.diagnosisDesc}`,
      orig: `${original.diagnosisCode} - ${original.diagnosisDesc}`,
      isMatch: currentClaim.diagnosisCode === original.diagnosisCode,
    },
    {
      label: 'Service Date',
      curr: currentClaim.serviceDate,
      orig: original.serviceDate,
      isMatch: currentClaim.serviceDate === original.serviceDate,
    },
    {
      label: 'Submission Date',
      curr: currentClaim.submissionDate,
      orig: original.submissionDate,
      isMatch: currentClaim.submissionDate === original.submissionDate,
    },
    {
      label: 'Billed Amount',
      curr: formatMoney(currentClaim.billedAmount),
      orig: formatMoney(original.billedAmount),
      isMatch: currentClaim.billedAmount === original.billedAmount,
    },
    {
      label: 'Units Billed',
      curr: `${currentClaim.units} unit(s)`,
      orig: `${original.units} unit(s)`,
      isMatch: currentClaim.units === original.units,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
              <ArrowRightLeft className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-semibold text-white">
                  Side-by-Side Duplicate Claim Collision Analysis
                </h3>
                <span className="font-mono text-xs px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800">
                  {match.similarity}% Collision Match ({match.matchType.replace('_', ' ').toUpperCase()})
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Comparing current incoming claim <span className="font-mono text-slate-200">{currentClaim.id}</span> against previously recorded claim <span className="font-mono text-slate-200">{original.id}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white text-sm px-2.5 py-1 rounded-lg border border-slate-800 hover:bg-slate-800 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Modal Body: Diff Matrix */}
        <div className="p-6 overflow-y-auto space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 p-3.5 bg-slate-950/80 rounded-xl border border-slate-800 text-xs">
            <div>
              <span className="text-slate-400 block mb-0.5">Collision Nature</span>
              <strong className="text-rose-400 font-medium">
                {match.matchType === 'exact'
                  ? 'Exact 100% duplicate billing'
                  : 'Near-duplicate (soft collision within 7 days)'}
              </strong>
            </div>
            <div>
              <span className="text-slate-400 block mb-0.5">Service Date Gap</span>
              <strong className="text-slate-200 font-mono">
                {match.dayDifference === 0 ? 'Same day (0 days offset)' : `${match.dayDifference} day(s) apart`}
              </strong>
            </div>
            <div>
              <span className="text-slate-400 block mb-0.5">Financial Delta</span>
              <strong className="text-slate-200 font-mono">
                {match.amountDifference === 0 ? 'Identical sum billed' : `Delta: ${formatMoney(match.amountDifference)}`}
              </strong>
            </div>
          </div>

          {/* Comparison Table */}
          <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-950/50">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-900/90 text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
                  <th className="py-2.5 px-4 w-1/4">Claim Field</th>
                  <th className="py-2.5 px-4 w-5/12 text-slate-200 bg-slate-900/60">
                    Incoming Claim ({currentClaim.id})
                  </th>
                  <th className="py-2.5 px-4 w-5/12 text-slate-300">
                    Matched Pre-Existing Claim ({original.id})
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {fields.map((f, i) => (
                  <tr key={i} className="hover:bg-slate-900/40 transition-colors">
                    <td className="py-2.5 px-4 font-medium text-slate-400 flex items-center gap-2">
                      {f.isMatch ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      ) : (
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      )}
                      <span>{f.label}</span>
                    </td>
                    <td className={`py-2.5 px-4 font-mono ${f.isMatch ? 'text-emerald-300 bg-emerald-950/15' : 'text-amber-200 bg-amber-950/15'}`}>
                      {f.curr}
                    </td>
                    <td className={`py-2.5 px-4 font-mono ${f.isMatch ? 'text-emerald-300 bg-emerald-950/10' : 'text-slate-300'}`}>
                      {f.orig}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="p-3.5 rounded-lg border border-rose-900/40 bg-rose-950/30 text-xs text-rose-300 flex items-start gap-2.5">
            <XCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-rose-200">Auditor Adjudication Recommendation</p>
              <p className="mt-0.5 text-rose-300/90">
                Reject incoming claim <span className="font-mono text-white">{currentClaim.id}</span> under CMS / IRDAI Anti-Duplication guidelines. Prior Claim <span className="font-mono text-white">{original.id}</span> has already been accounted for. Avoid double reimbursement.
              </p>
            </div>
          </div>
        </div>

        {/* Modal Footer Actions */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between gap-3">
          <button
            onClick={onDismissDuplicate}
            className="px-4 py-2 rounded-lg text-xs font-medium border border-slate-700 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
          >
            Dismiss Collision (Valid Medical Follow-up)
          </button>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs font-medium text-slate-400 hover:text-white transition-colors"
            >
              Close
            </button>
            <button
              onClick={onConfirmDuplicate}
              className="px-4 py-2 rounded-lg text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 shadow-md transition-colors"
            >
              Confirm Duplicate & Reject Claim
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
