import React, { useState } from 'react';
import { UserProfile } from '../types';
import {
  ShieldAlert,
  Building2,
  Stethoscope,
  Lock,
  Mail,
  Eye,
  EyeOff,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';

interface LoginPageProps {
  onLogin: (user: UserProfile) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [portalType, setPortalType] = useState<'company' | 'provider'>('company');
  const [email, setEmail] = useState('investigator.sethi@claimguard-insurance.com');
  const [password, setPassword] = useState('SecurePass2026!');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Switch portal type and adjust demo credentials
  const handleSwitchPortal = (type: 'company' | 'provider') => {
    setPortalType(type);
    setAuthError(null);
    if (type === 'company') {
      setEmail('investigator.sethi@claimguard-insurance.com');
      setPassword('SecurePass2026!');
    } else {
      setEmail('billing.desk@apexhospital.org');
      setPassword('HospitalApex2026#');
    }
  };

  const handleStandardSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);

    if (!email.trim() || !password.trim()) {
      setAuthError('Please enter both your work email and password.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      if (portalType === 'company') {
        const user: UserProfile = {
          id: 'USR-COMPANY-01',
          name: 'Vikram Sethi',
          email: email.trim(),
          role: 'insurer_auditor',
          portalType: 'company',
          organization: 'ClaimGuard General Health Insurance',
          department: 'Special Investigation Unit (SIU)',
        };
        onLogin(user);
      } else {
        const user: UserProfile = {
          id: 'USR-PROV-101',
          name: 'Dr. Anita Deshpande',
          email: email.trim(),
          role: 'healthcare_provider',
          portalType: 'provider',
          organization: 'Apex Multispecialty Hospital',
          facilityId: 'HSP-101',
          department: 'Revenue Cycle & Claims Compliance',
        };
        onLogin(user);
      }
    }, 500);
  };

  // Google Sign In handler
  const handleGoogleSignIn = () => {
    setIsLoading(true);
    setAuthError(null);
    setTimeout(() => {
      setIsLoading(false);
      if (portalType === 'company') {
        const user: UserProfile = {
          id: 'USR-GOOGLE-COMP',
          name: 'Vikram Sethi (Google)',
          email: 'vikram.sethi@claimguard-insurance.com',
          role: 'insurer_auditor',
          portalType: 'company',
          organization: 'ClaimGuard General Health Insurance',
          department: 'Special Investigation Unit (SIU)',
        };
        onLogin(user);
      } else {
        const user: UserProfile = {
          id: 'USR-GOOGLE-PROV',
          name: 'Dr. Anita Deshpande (Google)',
          email: 'anita.deshpande@apexhospital.org',
          role: 'healthcare_provider',
          portalType: 'provider',
          organization: 'Apex Multispecialty Hospital',
          facilityId: 'HSP-101',
          department: 'Medical Revenue Cycle',
        };
        onLogin(user);
      }
    }, 600);
  };

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col justify-between selection:bg-indigo-500/30 selection:text-white">
      {/* Top minimal header */}
      <header className="border-b border-slate-800/80 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-indigo-600 to-indigo-400 flex items-center justify-center text-white shadow-sm">
            <ShieldAlert className="w-4 h-4" />
          </div>
          <span className="text-base font-bold tracking-tight text-white">
            ClaimGuard AI
          </span>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>IRDAI & HIPAA Secure Gateway</span>
        </div>
      </header>

      {/* Main Login Container */}
      <div className="flex-1 flex items-center justify-center p-4 sm:p-6 my-6">
        <div className="w-full max-w-md space-y-6">
          {/* Header Title */}
          <div className="text-center space-y-1.5">
            <h1 className="text-2xl font-bold tracking-tight text-white">
              Welcome to ClaimGuard
            </h1>
            <p className="text-xs text-slate-400">
              Healthcare Claims Anomaly Detection & Forensic Review System
            </p>
          </div>

          {/* 2 Portal Switcher Tabs */}
          <div className="p-1 bg-slate-900/90 rounded-xl border border-slate-800 grid grid-cols-2 gap-1 text-xs">
            <button
              type="button"
              onClick={() => handleSwitchPortal('company')}
              className={`py-2.5 px-3 rounded-lg font-medium transition-all flex items-center justify-center gap-2 ${
                portalType === 'company'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>The Company (Insurer / SIU)</span>
            </button>

            <button
              type="button"
              onClick={() => handleSwitchPortal('provider')}
              className={`py-2.5 px-3 rounded-lg font-medium transition-all flex items-center justify-center gap-2 ${
                portalType === 'provider'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Stethoscope className="w-3.5 h-3.5" />
              <span>Hospitals & Clinics</span>
            </button>
          </div>

          {/* Portal Context Notice Card */}
          <div className="p-3 rounded-xl border border-slate-800/80 bg-slate-900/50 text-xs">
            {portalType === 'company' ? (
              <div className="flex items-start gap-2.5">
                <Building2 className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-slate-200 block">
                    Payer & Insurance Company Portal
                  </span>
                  <p className="text-slate-400 text-[11px] mt-0.5">
                    For Claims Examiners, SIU Fraud Investigators, and Medical Auditors reviewing suspicious claims, SHAP explanations, and adjudications.
                  </p>
                </div>
              </div>
            ) : (
              <div className="flex items-start gap-2.5">
                <Stethoscope className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-slate-200 block">
                    Healthcare Provider & Hospital Portal
                  </span>
                  <p className="text-slate-400 text-[11px] mt-0.5">
                    For Hospitals, Clinics, and Doctors to submit claims, run real-time AI pre-validation, respond to RFIs, and track adjudication status.
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Main Form Card */}
          <div className="bg-slate-900/80 border border-slate-800/90 rounded-2xl p-6 shadow-xl backdrop-blur space-y-5">
            {/* Google Sign In Button */}
            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={isLoading}
              className="w-full py-2.5 px-4 rounded-xl border border-slate-700 bg-slate-950/80 hover:bg-slate-800 text-xs font-semibold text-slate-200 flex items-center justify-center gap-3 transition-colors shadow-sm disabled:opacity-50"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>Sign in with Google</span>
            </button>

            {/* Visual Divider */}
            <div className="relative flex items-center justify-center">
              <div className="border-t border-slate-800 w-full" />
              <span className="bg-slate-900 px-3 text-[11px] text-slate-500 uppercase tracking-wider font-mono">
                or work credentials
              </span>
            </div>

            {/* Error Message if any */}
            {authError && (
              <div className="p-3 rounded-lg bg-rose-950/70 border border-rose-800 text-xs text-rose-300 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{authError}</span>
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleStandardSubmit} className="space-y-4 text-xs">
              <div>
                <label className="text-slate-300 block font-medium mb-1.5">
                  {portalType === 'company' ? 'Insurer Examiner Email' : 'Hospital Billing / Doctor Email'}
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="text-slate-300 font-medium">Password</label>
                  <button
                    type="button"
                    onClick={() =>
                      alert(
                        'Password reset instructions sent to registered administrator email address.'
                      )
                    }
                    className="text-[11px] text-indigo-400 hover:text-indigo-300"
                  >
                    Forgot password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-10 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-300"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between pt-1">
                <label className="flex items-center gap-2 cursor-pointer select-none text-slate-400">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="rounded border-slate-800 text-indigo-600 focus:ring-0 bg-slate-950"
                  />
                  <span>Keep me logged in on this device</span>
                </label>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 shadow-lg shadow-indigo-600/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <span>{isLoading ? 'Verifying Credentials...' : `Sign in to ${portalType === 'company' ? 'Insurer' : 'Provider'} Portal`}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>

            {/* Quick Demo Pre-fill helper */}
            <div className="pt-3 border-t border-slate-800/80 text-[11px] text-slate-400 flex items-center justify-between">
              <span>Demo Account: <strong className="text-slate-200">{portalType === 'company' ? 'SIU Auditor' : 'Apex Hospital'}</strong></span>
              <button
                type="button"
                onClick={() => {
                  if (portalType === 'company') {
                    setEmail('investigator.sethi@claimguard-insurance.com');
                    setPassword('SecurePass2026!');
                  } else {
                    setEmail('billing.desk@apexhospital.org');
                    setPassword('HospitalApex2026#');
                  }
                }}
                className="text-indigo-400 hover:text-indigo-300 underline"
              >
                Reset Pre-fill
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Footer Security Badges */}
      <footer className="border-t border-slate-900 bg-slate-950/50 py-4 px-6 text-center text-[11px] text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2 max-w-7xl mx-auto w-full">
        <span>ClaimGuard AI · Healthcare Claims Anomaly Detection System</span>
        <div className="flex items-center gap-4 font-mono">
          <span>AES-256 Bit Encryption</span>
          <span>·</span>
          <span>SOC-2 Type II Certified</span>
          <span>·</span>
          <span>HIPAA & IRDAI Guidelines Compliant</span>
        </div>
      </footer>
    </div>
  );
};
