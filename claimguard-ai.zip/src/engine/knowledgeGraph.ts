export interface DiagnosisInfo {
  code: string;
  name: string;
  category: string;
  typicalSpecialties: string[];
  allowedGender?: 'M' | 'F';
  minAge?: number;
  maxAge?: number;
}

export interface ProcedureInfo {
  code: string;
  name: string;
  specialty: string;
  peerMeanAmount: number; // INR
  peerStdDev: number; // INR
  maxStandardUnits: number;
  allowedGender?: 'M' | 'F';
  requiresPriorAuth: boolean;
  compatibleDiagnoses: string[]; // ICD-10 codes or prefixes
  mutuallyExclusiveCodes?: string[]; // CCI unbundling edits
}

export const DIAGNOSES_DATABASE: Record<string, DiagnosisInfo> = {
  'J00': {
    code: 'J00',
    name: 'Acute nasopharyngitis (Common cold)',
    category: 'Respiratory',
    typicalSpecialties: ['General Medicine', 'Pediatrics', 'Family Practice'],
  },
  'I25.10': {
    code: 'I25.10',
    name: 'Atherosclerotic heart disease of native coronary artery',
    category: 'Cardiovascular',
    typicalSpecialties: ['Cardiology', 'Cardiothoracic Surgery'],
    minAge: 25,
  },
  'M17.11': {
    code: 'M17.11',
    name: 'Unilateral primary osteoarthritis, right knee',
    category: 'Musculoskeletal',
    typicalSpecialties: ['Orthopedics', 'Rheumatology'],
    minAge: 35,
  },
  'R07.9': {
    code: 'R07.9',
    name: 'Chest pain, unspecified',
    category: 'Symptoms / Cardiology',
    typicalSpecialties: ['Cardiology', 'Emergency Medicine', 'General Medicine'],
  },
  'M54.5': {
    code: 'M54.5',
    name: 'Low back pain, non-radicular',
    category: 'Musculoskeletal',
    typicalSpecialties: ['Orthopedics', 'Physical Medicine', 'General Medicine'],
  },
  'G43.909': {
    code: 'G43.909',
    name: 'Migraine, unspecified, not intractable, without status migrainosus',
    category: 'Neurological',
    typicalSpecialties: ['Neurology', 'General Medicine'],
  },
  'H25.9': {
    code: 'H25.9',
    name: 'Age-related cataract, unspecified',
    category: 'Ophthalmology',
    typicalSpecialties: ['Ophthalmology'],
    minAge: 45,
  },
  'E11.9': {
    code: 'E11.9',
    name: 'Type 2 diabetes mellitus without complications',
    category: 'Endocrinology',
    typicalSpecialties: ['Endocrinology', 'General Medicine'],
  },
  'C50.919': {
    code: 'C50.919',
    name: 'Malignant neoplasm of unspecified site of female breast',
    category: 'Oncology',
    typicalSpecialties: ['Oncology', 'Surgical Oncology'],
    allowedGender: 'F',
  },
  'N40.0': {
    code: 'N40.0',
    name: 'Benign prostatic hyperplasia without lower urinary tract symptoms',
    category: 'Urology',
    typicalSpecialties: ['Urology'],
    allowedGender: 'M',
    minAge: 40,
  },
};

export const PROCEDURES_DATABASE: Record<string, ProcedureInfo> = {
  '33533': {
    code: '33533',
    name: 'Coronary artery bypass, using arterial graft(s); single arterial graft',
    specialty: 'Cardiology',
    peerMeanAmount: 320000,
    peerStdDev: 65000,
    maxStandardUnits: 1,
    requiresPriorAuth: true,
    compatibleDiagnoses: ['I25.10', 'I25.11', 'I21.0'],
    mutuallyExclusiveCodes: ['99213', '99214'], // cannot bill minor office visit on same major surgical date
  },
  '70553': {
    code: '70553',
    name: 'Magnetic resonance imaging (MRI), brain; with and without contrast material',
    specialty: 'Radiology',
    peerMeanAmount: 7500,
    peerStdDev: 1500,
    maxStandardUnits: 1,
    requiresPriorAuth: true,
    compatibleDiagnoses: ['G43.909', 'R07.9', 'C71.9', 'G40.9'],
  },
  '27447': {
    code: '27447',
    name: 'Arthroplasty, knee, condyle and plateau; medical and lateral compartments with or without patella resurfacing (total knee arthroplasty)',
    specialty: 'Orthopedics',
    peerMeanAmount: 240000,
    peerStdDev: 42000,
    maxStandardUnits: 1,
    requiresPriorAuth: true,
    compatibleDiagnoses: ['M17.11', 'M17.12', 'M17.9'],
    mutuallyExclusiveCodes: ['29881', '29877'], // unbundling arthroscopic debridement with total knee
  },
  '29881': {
    code: '29881',
    name: 'Arthroscopy, knee, surgical; with meniscectomy (medial OR lateral)',
    specialty: 'Orthopedics',
    peerMeanAmount: 65000,
    peerStdDev: 12000,
    maxStandardUnits: 1,
    requiresPriorAuth: true,
    compatibleDiagnoses: ['M17.11', 'M23.2'],
  },
  '99213': {
    code: '99213',
    name: 'Office or other outpatient visit for evaluation and management, low-to-moderate complexity',
    specialty: 'General Medicine',
    peerMeanAmount: 1200,
    peerStdDev: 350,
    maxStandardUnits: 1,
    requiresPriorAuth: false,
    compatibleDiagnoses: ['J00', 'E11.9', 'M54.5', 'R07.9', 'I10'],
  },
  '99215': {
    code: '99215',
    name: 'Office or other outpatient visit for evaluation and management, high medical decision making / complexity',
    specialty: 'General Medicine',
    peerMeanAmount: 3800,
    peerStdDev: 700,
    maxStandardUnits: 1,
    requiresPriorAuth: false,
    compatibleDiagnoses: ['I25.10', 'C50.919', 'E11.69'],
  },
  '99291': {
    code: '99291',
    name: 'Critical care, evaluation and management of the critically ill or critically injured patient; first 30-74 minutes',
    specialty: 'Critical Care',
    peerMeanAmount: 18500,
    peerStdDev: 3800,
    maxStandardUnits: 1,
    requiresPriorAuth: false,
    compatibleDiagnoses: ['I21.0', 'R57.0', 'J96.00'],
  },
  '66984': {
    code: '66984',
    name: 'Extracapsular cataract removal with insertion of intraocular lens prosthesis (1 stage procedure)',
    specialty: 'Ophthalmology',
    peerMeanAmount: 35000,
    peerStdDev: 6000,
    maxStandardUnits: 1,
    requiresPriorAuth: true,
    compatibleDiagnoses: ['H25.9', 'H26.9'],
  },
  '97110': {
    code: '97110',
    name: 'Therapeutic procedure, 1 or more areas, each 15 minutes; therapeutic exercises to develop strength and endurance, range of motion',
    specialty: 'Physical Medicine',
    peerMeanAmount: 950,
    peerStdDev: 220,
    maxStandardUnits: 4,
    requiresPriorAuth: false,
    compatibleDiagnoses: ['M54.5', 'M17.11', 'M25.561'],
  },
  '96413': {
    code: '96413',
    name: 'Chemotherapy administration, intravenous infusion technique; up to 1 hour, single or initial substance/drug',
    specialty: 'Oncology',
    peerMeanAmount: 48000,
    peerStdDev: 9500,
    maxStandardUnits: 1,
    requiresPriorAuth: true,
    compatibleDiagnoses: ['C50.919', 'C34.90', 'C18.9'],
  },
};

export const SPECIALTY_BENCHMARKS: Record<
  string,
  {
    avgMonthlyVolumePerProvider: number;
    peerDenialRate: number;
    typicalTicketAvg: number;
  }
> = {
  Cardiology: {
    avgMonthlyVolumePerProvider: 32,
    peerDenialRate: 4.8,
    typicalTicketAvg: 185000,
  },
  Radiology: {
    avgMonthlyVolumePerProvider: 45,
    peerDenialRate: 2.9,
    typicalTicketAvg: 6800,
  },
  Orthopedics: {
    avgMonthlyVolumePerProvider: 28,
    peerDenialRate: 5.1,
    typicalTicketAvg: 145000,
  },
  'General Medicine': {
    avgMonthlyVolumePerProvider: 160,
    peerDenialRate: 2.1,
    typicalTicketAvg: 1450,
  },
  Ophthalmology: {
    avgMonthlyVolumePerProvider: 40,
    peerDenialRate: 1.8,
    typicalTicketAvg: 32000,
  },
  Oncology: {
    avgMonthlyVolumePerProvider: 24,
    peerDenialRate: 3.5,
    typicalTicketAvg: 62000,
  },
  'Physical Medicine': {
    avgMonthlyVolumePerProvider: 85,
    peerDenialRate: 4.2,
    typicalTicketAvg: 1200,
  },
  'Critical Care': {
    avgMonthlyVolumePerProvider: 22,
    peerDenialRate: 6.0,
    typicalTicketAvg: 28000,
  },
};
